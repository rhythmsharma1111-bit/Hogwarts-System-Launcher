package com.hogwarts.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs
import kotlin.math.max

class HomeActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var scene: SceneView
    private lateinit var pager: ViewPager2
    private lateinit var dots: DotsView
    private lateinit var clock: TextView
    private lateinit var dateTv: TextView
    private lateinit var dock: LinearLayout
    private lateinit var drawer: DrawerView
    private var batteryTv: TextView? = null

    private val handler = Handler(Looper.getMainLooper())
    private var builtHouse = -2
    private var lastClockTap = 0L
    private var tdx = 0f
    private var tdy = 0f
    private var tdt = 0L

    private val ticker = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 1000)
        }
    }
    private val appsL: () -> Unit = { onAppsChanged() }
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            AppRepo.load(this@HomeActivity)
        }
    }

    private class PageHolder(v: View) : RecyclerView.ViewHolder(v)

    private inner class PagesAdapter : RecyclerView.Adapter<PageHolder>() {
        override fun getItemCount(): Int = 1 + gridPageCount()

        override fun getItemViewType(position: Int): Int = if (position == 0) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageHolder {
            val v: View
            if (viewType == 0) {
                v = buildWidgetsPage()
            } else {
                val l = LinearLayout(this@HomeActivity)
                l.orientation = LinearLayout.VERTICAL
                l.setPadding(dp(10), dp(4), dp(10), dp(4))
                v = l
            }
            v.layoutParams = ViewGroup.LayoutParams(MP, MP)
            return PageHolder(v)
        }

        override fun onBindViewHolder(holder: PageHolder, position: Int) {
            if (position > 0) fillGrid(holder.itemView as LinearLayout, position - 1)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        builtHouse = Prefs.house

        root = FrameLayout(this)
        scene = SceneView(this)
        root.addView(scene, FrameLayout.LayoutParams(MP, MP))

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        root.addView(content, FrameLayout.LayoutParams(MP, MP))

        clock = Ui.text(this, "", 66f, Color.WHITE, Ui.serif)
        clock.gravity = Gravity.CENTER
        clock.setShadowLayer(26f, 0f, 0f, House.glow())
        clock.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - lastClockTap < 350) {
                if (!HogwartsAccessibilityService.lockScreen()) {
                    Toast.makeText(this, "Turn on Hogwarts Magic in Accessibility to lock with a double tap", Toast.LENGTH_LONG).show()
                }
            }
            lastClockTap = now
        }
        clock.setOnLongClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            true
        }
        dateTv = Ui.text(this, "", 15f, Color.parseColor("#E6E8F5"), Ui.serifItalic)
        dateTv.gravity = Gravity.CENTER
        content.addView(clock, LinearLayout.LayoutParams(MP, WC))
        content.addView(dateTv, LinearLayout.LayoutParams(MP, WC))

        pager = ViewPager2(this)
        pager.adapter = PagesAdapter()
        pager.offscreenPageLimit = 1
        pager.setPageTransformer { page, pos ->
            val p = pos.coerceIn(-1f, 1f)
            page.cameraDistance = resources.displayMetrics.density * 9000f
            page.pivotX = if (p < 0f) page.width.toFloat() else 0f
            page.pivotY = page.height / 2f
            page.rotationY = -30f * p
            page.alpha = 1f - 0.55f * abs(p)
        }
        dots = DotsView(this)
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                dots.pos = position + positionOffset
            }
        })
        val plp = LinearLayout.LayoutParams(MP, 0, 1f)
        plp.topMargin = dp(8)
        content.addView(pager, plp)
        content.addView(dots, LinearLayout.LayoutParams(MP, dp(18)))

        val chev = Ui.text(this, "\u2191  swipe up  \u2191", 11f, House.glow(), Ui.serifItalic)
        chev.gravity = Gravity.CENTER
        chev.setOnClickListener { drawer.open() }
        content.addView(chev, LinearLayout.LayoutParams(MP, dp(26)))

        dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER
        dock.background = Ui.glass(this, 30f, 120, 80)
        dock.setPadding(dp(8), dp(8), dp(8), dp(8))
        val dlp = LinearLayout.LayoutParams(MP, dp(90))
        dlp.leftMargin = dp(14)
        dlp.rightMargin = dp(14)
        dlp.bottomMargin = dp(10)
        content.addView(dock, dlp)

        drawer = DrawerView(this, this)
        root.addView(drawer, FrameLayout.LayoutParams(MP, MP))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val bars = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            content.setPadding(0, bars.top + dp(10), 0, bars.bottom)
            drawer.setInsets(bars.top, bars.bottom)
            ins
        }

        AppRepo.addListener(appsL)
        AppRepo.load(this)
        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addAction(Intent.ACTION_PACKAGE_CHANGED)
        f.addAction(Intent.ACTION_PACKAGE_REPLACED)
        f.addDataScheme("package")
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)

        updateClock()
        if (AppRepo.apps.isNotEmpty()) onAppsChanged()
        if (Prefs.house < 0) startActivity(Intent(this, SortingHatActivity::class.java))
    }

    override fun onResume() {
        super.onResume()
        if (builtHouse != Prefs.house) {
            recreate()
            return
        }
        scene.running = true
        Tilt.start(this)
        handler.post(ticker)
        updateBattery()
    }

    override fun onPause() {
        scene.running = false
        Tilt.stop()
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        AppRepo.removeListener(appsL)
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (drawer.isOpen) drawer.close() else pager.currentItem = 0
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (drawer.isOpen) drawer.close()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                tdx = ev.rawX
                tdy = ev.rawY
                tdt = ev.eventTime
            }
            MotionEvent.ACTION_UP -> {
                val dy = ev.rawY - tdy
                val dx = ev.rawX - tdx
                if (!drawer.isOpen && dy < -dp(90) && abs(dy) > abs(dx) * 1.6f && ev.eventTime - tdt < 700) {
                    drawer.open()
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    // ---- data -------------------------------------------------------------

    private fun pinnedItems(): List<AppItem> = Prefs.list("pins").mapNotNull { AppRepo.byKey[it] }

    private fun gridPageCount(): Int = max(1, (pinnedItems().size + 19) / 20)

    private fun onAppsChanged() {
        if (!Prefs.dockInit && AppRepo.apps.isNotEmpty()) {
            Prefs.putList("dock", AppRepo.defaultDock(this).take(4))
            Prefs.dockInit = true
        }
        refreshPages()
        refreshDock()
        drawer.refreshApps()
    }

    private fun refreshPages() {
        pager.adapter?.notifyDataSetChanged()
        dots.count = 1 + gridPageCount()
    }

    private fun refreshDock() {
        dock.removeAllViews()
        for (k in Prefs.list("dock")) {
            val a = AppRepo.byKey[k] ?: continue
            val cell = AppCell(this, 58, false)
            cell.bind(a)
            cell.gravity = Gravity.CENTER
            cell.setOnClickListener { launch(it, a) }
            cell.setOnLongClickListener {
                appMenu(it, a)
                true
            }
            dock.addView(cell, LinearLayout.LayoutParams(0, MP, 1f))
        }
    }

    private fun fillGrid(col: LinearLayout, page: Int) {
        col.removeAllViews()
        val items = pinnedItems()
        if (items.isEmpty()) {
            val t = Ui.text(
                this,
                "Your castle is empty.\nLong-press an app in the drawer\nand choose \u201CPin to Home\u201D.",
                14f, Color.parseColor("#C9CCE0"), Ui.serifItalic
            )
            t.gravity = Gravity.CENTER
            col.addView(t, LinearLayout.LayoutParams(MP, MP))
            return
        }
        val start = page * 20
        for (r in 0 until 5) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until 4) {
                val cellHost = FrameLayout(this)
                val idx = start + r * 4 + c
                if (idx < items.size) {
                    val item = items[idx]
                    val cell = AppCell(this, 60, true)
                    cell.bind(item)
                    cell.setOnClickListener { launch(it, item) }
                    cell.setOnLongClickListener {
                        appMenu(it, item)
                        true
                    }
                    cellHost.addView(cell, FrameLayout.LayoutParams(WC, WC, Gravity.CENTER))
                }
                row.addView(cellHost, LinearLayout.LayoutParams(0, MP, 1f))
            }
            col.addView(row, LinearLayout.LayoutParams(MP, 0, 1f))
        }
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = Ui.glass(this, 24f, 130, 80)
        l.setPadding(dp(18), dp(14), dp(18), dp(14))
        return l
    }

    private fun buildWidgetsPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(6), dp(18), dp(6))
        val glow = House.glow()
        val muted = Color.parseColor("#C9CCE0")

        val sp = Spells.today()
        val c1 = card()
        val k = Ui.text(this, "\u2726  SPELL OF THE DAY", 11f, glow)
        k.letterSpacing = 0.18f
        c1.addView(k)
        c1.addView(Ui.text(this, sp.first, 28f, Color.WHITE, Ui.serifBold))
        c1.addView(Ui.text(this, sp.second, 13.5f, muted, Ui.serifItalic))
        col.addView(c1, LinearLayout.LayoutParams(MP, WC))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val c2 = card()
        c2.addView(Ui.text(this, "HOUSE", 10.5f, glow))
        c2.addView(Ui.text(this, House.name(), 20f, Color.WHITE, Ui.serifBold))
        c2.addView(Ui.text(this, House.mottos[House.idx()], 11.5f, muted, Ui.serifItalic))
        val c3 = card()
        c3.addView(Ui.text(this, "BATTERY", 10.5f, glow))
        val bt = Ui.text(this, "", 20f, Color.WHITE, Ui.serifBold)
        batteryTv = bt
        c3.addView(bt)
        val lp2 = LinearLayout.LayoutParams(0, MP, 1.4f)
        lp2.rightMargin = dp(10)
        row.addView(c2, lp2)
        row.addView(c3, LinearLayout.LayoutParams(0, MP, 1f))
        val rlp = LinearLayout.LayoutParams(MP, WC)
        rlp.topMargin = dp(12)
        col.addView(row, rlp)

        val spells = LinearLayout(this)
        spells.orientation = LinearLayout.HORIZONTAL
        fun spell(emoji: String, name: String, act: () -> Unit) {
            val box = card()
            box.gravity = Gravity.CENTER_HORIZONTAL
            box.addView(Ui.text(this, emoji, 26f))
            box.addView(Ui.text(this, name, 12f, Color.WHITE, Ui.serif))
            box.setOnClickListener { act() }
            val lp = LinearLayout.LayoutParams(0, WC, 1f)
            lp.leftMargin = dp(5)
            lp.rightMargin = dp(5)
            spells.addView(box, lp)
        }
        spell("\uD83D\uDD26", "Lumos") { Torch.toggle(this) }
        spell("\uD83D\uDD0D", "Accio") {
            drawer.open()
            handler.postDelayed({ drawer.focusSearch() }, 420)
        }
        spell("\uD83D\uDDDD\uFE0F", "Alohomora") { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        val slp = LinearLayout.LayoutParams(MP, WC)
        slp.topMargin = dp(12)
        col.addView(spells, slp)

        val tip = Ui.text(this, "Pull down from the top-left for Owl Post, top-right for Enchantments.\nDouble-tap the clock to lock. Hold the clock for setup.", 11.5f, Color.parseColor("#9AA0BD"), Ui.serifItalic)
        tip.gravity = Gravity.CENTER
        val tlp = LinearLayout.LayoutParams(MP, WC)
        tlp.topMargin = dp(18)
        col.addView(tip, tlp)
        return col
    }

    private fun updateClock() {
        clock.text = Fmt.time(this)
        dateTv.text = Fmt.date()
    }

    private fun updateBattery() {
        val tv = batteryTv ?: return
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else 0
        tv.text = pct.toString() + "%" + (if (charging) "  \u26A1" else "")
    }

    // ---- actions ----------------------------------------------------------

    fun launch(v: View, item: AppItem) {
        try {
            val o = ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height)
            startActivity(item.intent(), o.toBundle())
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open " + item.label, Toast.LENGTH_SHORT).show()
        }
        if (drawer.isOpen) handler.postDelayed({ drawer.close() }, 250)
    }

    fun launchPlain(item: AppItem) {
        try {
            startActivity(item.intent())
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open " + item.label, Toast.LENGTH_SHORT).show()
        }
        drawer.close()
    }

    fun appMenu(anchor: View, item: AppItem) {
        val pins = Prefs.list("pins")
        val dk = Prefs.list("dock")
        val entries = ArrayList<Pair<String, () -> Unit>>()
        fun add(label: String, act: () -> Unit) {
            entries.add(Pair(label, act))
        }
        if (pins.contains(item.key)) {
            add("Remove from Home") {
                pins.remove(item.key)
                Prefs.putList("pins", pins)
                refreshPages()
            }
        } else {
            add("Pin to Home") {
                pins.add(item.key)
                Prefs.putList("pins", pins)
                refreshPages()
                Toast.makeText(this, item.label + " pinned to Home", Toast.LENGTH_SHORT).show()
            }
        }
        if (dk.contains(item.key)) {
            add("Remove from Dock") {
                dk.remove(item.key)
                Prefs.putList("dock", dk)
                refreshDock()
            }
        } else if (dk.size < 4) {
            add("Add to Dock") {
                dk.add(item.key)
                Prefs.putList("dock", dk)
                refreshDock()
            }
        }
        add("App info") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + item.pkg)))
        }
        add("Uninstall") {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + item.pkg)))
        }
        ActionMenu.show(anchor, entries)
    }
}
