package com.hogwarts.launcher

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/**
 * The Hogwarts lock screen. It sits in front of the real Android lock screen; swiping up asks
 * Android to dismiss its keyguard, so your PIN / fingerprint still protects the phone.
 */
class LockActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var col: LinearLayout
    private lateinit var scene: SceneView
    private lateinit var clock: TextView
    private lateinit var dateTv: TextView
    private lateinit var notifBox: LinearLayout
    private lateinit var hint: TextView
    private lateinit var sparks: SparkView
    private lateinit var lumos: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var hintAnim: ObjectAnimator? = null
    private var downY = 0f
    private var unlocking = false

    private val tick = object : Runnable {
        override fun run() {
            clock.text = Fmt.time(this@LockActivity)
            dateTv.text = Fmt.date()
            handler.postDelayed(this, 1000)
        }
    }
    private val notifL: () -> Unit = { renderNotifs() }
    private val present = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            finishAndRemoveTask()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        root = FrameLayout(this)
        scene = SceneView(this)
        scene.lockMode = true
        root.addView(scene, FrameLayout.LayoutParams(MP, MP))

        content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(MP, MP))

        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        content.addView(col, FrameLayout.LayoutParams(MP, MP))

        clock = Ui.text(this, "", 88f, Color.WHITE, Ui.serif)
        clock.gravity = Gravity.CENTER
        clock.setShadowLayer(34f, 0f, 0f, House.glow())
        col.addView(clock, LinearLayout.LayoutParams(MP, WC))
        dateTv = Ui.text(this, "", 18f, Color.parseColor("#F0F1FA"), Ui.serifItalic)
        dateTv.gravity = Gravity.CENTER
        col.addView(dateTv, LinearLayout.LayoutParams(MP, WC))

        val sp = Spells.today()
        val spell = Ui.text(this, "\u2726 " + sp.first + " \u2014 " + sp.second, 12.5f, Ui.alpha(House.glow(), 230), Ui.serifItalic)
        spell.gravity = Gravity.CENTER
        spell.setPadding(dp(28), 0, dp(28), 0)
        val splp = LinearLayout.LayoutParams(MP, WC)
        splp.topMargin = dp(14)
        col.addView(spell, splp)

        col.addView(View(this), LinearLayout.LayoutParams(MP, 0, 1f))

        notifBox = LinearLayout(this)
        notifBox.orientation = LinearLayout.VERTICAL
        val nlp = LinearLayout.LayoutParams(MP, WC)
        nlp.leftMargin = dp(18)
        nlp.rightMargin = dp(18)
        col.addView(notifBox, nlp)

        val bottom = FrameLayout(this)
        lumos = Ui.text(this, "\uD83D\uDD26", 22f)
        lumos.gravity = Gravity.CENTER
        setCircle(lumos, Torch.on)
        lumos.setOnClickListener {
            Torch.toggle(this)
            setCircle(lumos, Torch.on)
        }
        val llp = FrameLayout.LayoutParams(dp(54), dp(54), Gravity.START or Gravity.CENTER_VERTICAL)
        llp.leftMargin = dp(30)
        bottom.addView(lumos, llp)

        hint = Ui.text(this, "\u2726  swipe up to enter  \u2726", 14f, Color.WHITE, Ui.serifItalic)
        hint.gravity = Gravity.CENTER
        bottom.addView(hint, FrameLayout.LayoutParams(WC, WC, Gravity.CENTER))

        val cam = Ui.text(this, "\uD83D\uDCF7", 22f)
        cam.gravity = Gravity.CENTER
        setCircle(cam, false)
        cam.setOnClickListener { openCamera() }
        val clp = FrameLayout.LayoutParams(dp(54), dp(54), Gravity.END or Gravity.CENTER_VERTICAL)
        clp.rightMargin = dp(30)
        bottom.addView(cam, clp)
        col.addView(bottom, LinearLayout.LayoutParams(MP, dp(96)))

        sparks = SparkView(this)
        root.addView(sparks, FrameLayout.LayoutParams(MP, MP))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val bars = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            col.setPadding(0, bars.top + dp(56), 0, bars.bottom + dp(8))
            ins
        }

        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.rawY
                    sparks.emit(e.x, e.y)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = (downY - e.rawY).coerceAtLeast(0f)
                    content.translationY = -dy * 0.9f
                    content.alpha = (1f - dy / (root.height * 1.1f)).coerceIn(0.2f, 1f)
                    sparks.emit(e.x, e.y)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dy = downY - e.rawY
                    if (dy > root.height * 0.18f) unlock() else reset()
                }
            }
            true
        }

        ContextCompat.registerReceiver(this, present, IntentFilter(Intent.ACTION_USER_PRESENT), ContextCompat.RECEIVER_NOT_EXPORTED)
        val a = ObjectAnimator.ofFloat(hint, "alpha", 0.35f, 1f)
        a.duration = 1300
        a.repeatCount = ValueAnimator.INFINITE
        a.repeatMode = ValueAnimator.REVERSE
        a.start()
        hintAnim = a
    }

    private fun setCircle(v: TextView, on: Boolean) {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        if (on) {
            g.setColor(Ui.alpha(House.glow(), 230))
        } else {
            g.setColor(Color.argb(120, 20, 24, 50))
            g.setStroke(dp(1), Color.argb(90, 255, 255, 255))
        }
        v.background = g
    }

    private fun openCamera() {
        try {
            val i = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            } catch (e2: Exception) {
            }
        }
    }

    private fun addCard(title: String, text: String, icon: android.graphics.Bitmap?) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = Ui.glass(this, 20f, 150, 80)
        row.setPadding(dp(12), dp(10), dp(12), dp(10))
        if (icon != null) {
            val iv = ImageView(this)
            iv.setImageBitmap(icon)
            row.addView(iv, LinearLayout.LayoutParams(dp(32), dp(32)))
        }
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        val t = Ui.text(this, title, 14f, Color.WHITE, Ui.serifBold)
        t.maxLines = 1
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        tcol.addView(t)
        if (text.isNotEmpty()) {
            val s = Ui.text(this, text, 12.5f, Color.parseColor("#C9CCE0"))
            s.maxLines = 1
            s.ellipsize = android.text.TextUtils.TruncateAt.END
            tcol.addView(s)
        }
        val lp = LinearLayout.LayoutParams(0, WC, 1f)
        if (icon != null) lp.leftMargin = dp(10)
        row.addView(tcol, lp)
        val rlp = LinearLayout.LayoutParams(MP, WC)
        rlp.bottomMargin = dp(8)
        notifBox.addView(row, rlp)
    }

    private fun renderNotifs() {
        notifBox.removeAllViews()
        val all = ArrayList(Hub.notifs)
        if (all.isEmpty()) return
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (km.isDeviceLocked) {
            // Keep the content private while the phone is locked.
            val apps = all.map { it.app }.distinct().take(3).joinToString(", ")
            val n = all.size
            addCard(n.toString() + (if (n > 1) " new notifications" else " new notification"), apps, null)
        } else {
            for (n in all.take(3)) {
                addCard(if (n.title.isNotEmpty()) n.title else n.app, n.text, n.icon)
            }
        }
    }

    private fun reset() {
        unlocking = false
        content.animate().translationY(0f).alpha(1f).setDuration(220).start()
    }

    private fun unlock() {
        if (unlocking) return
        unlocking = true
        content.animate().translationY(-root.height.toFloat()).alpha(0f).setDuration(220).start()
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    finishAndRemoveTask()
                }

                override fun onDismissCancelled() {
                    reset()
                }

                override fun onDismissError() {
                    reset()
                }
            })
        } else {
            finishAndRemoveTask()
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        reset()
    }

    override fun onResume() {
        super.onResume()
        scene.running = true
        Tilt.start(this)
        handler.post(tick)
        Hub.onNotifs(notifL)
        renderNotifs()
        setCircle(lumos, Torch.on)
    }

    override fun onPause() {
        scene.running = false
        Tilt.stop()
        handler.removeCallbacks(tick)
        Hub.offNotifs(notifL)
        super.onPause()
    }

    override fun onDestroy() {
        hintAnim?.cancel()
        try {
            unregisterReceiver(present)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
    }
}
