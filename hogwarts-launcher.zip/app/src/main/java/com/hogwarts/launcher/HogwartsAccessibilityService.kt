package com.hogwarts.launcher

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import androidx.core.content.ContextCompat

/**
 * Runs the "over every app" magic: dynamic island, swipe-down notification centre (top-left),
 * swipe-down control centre (top-right), and launches the Hogwarts lock screen when the screen turns off.
 */
class HogwartsAccessibilityService : AccessibilityService() {
    companion object {
        var instance: HogwartsAccessibilityService? = null

        fun lockScreen(): Boolean {
            val s = instance ?: return false
            return s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        }
    }

    private lateinit var wm: WindowManager
    private var island: Island? = null
    private var stripL: View? = null
    private var stripR: View? = null
    private var panelRoot: FrameLayout? = null
    private var panelContent: View? = null
    private var panelDim: View? = null
    private var closing = false
    private var receiverOn = false

    private val postedL: (NotifItem) -> Unit = { n -> island?.showNotification(n) }
    private val mediaL: () -> Unit = { island?.onMediaChanged() }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    closePanel()
                    if (Prefs.lockEnabled) launchLock()
                }
                Intent.ACTION_POWER_CONNECTED -> island?.showCharging()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildOverlays()
        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_OFF)
        f.addAction(Intent.ACTION_POWER_CONNECTED)
        if (!receiverOn) {
            ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverOn = true
        }
        Hub.onPosted(postedL)
        Hub.onMedia(mediaL)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        Hub.offPosted(postedL)
        Hub.offMedia(mediaL)
        if (receiverOn) {
            try {
                unregisterReceiver(receiver)
            } catch (e: Exception) {
            }
            receiverOn = false
        }
        panelRoot?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        panelRoot = null
        panelContent = null
        panelDim = null
        removeOverlays()
        if (instance === this) instance = null
    }

    /** Called from the settings screen after a preference changed. */
    fun applyPrefs() {
        removeOverlays()
        buildOverlays()
    }

    private fun buildOverlays() {
        val isl = Island(this, wm)
        island = isl
        isl.start()
        if (Prefs.strips) {
            addStrip(true)
            addStrip(false)
        }
    }

    private fun removeOverlays() {
        island?.destroy()
        island = null
        val views = listOf(stripL, stripR)
        for (v in views) {
            if (v != null) {
                try {
                    wm.removeView(v)
                } catch (e: Exception) {
                }
            }
        }
        stripL = null
        stripR = null
    }

    private fun addStrip(left: Boolean) {
        val v = View(this)
        var downY = 0f
        var fired = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.rawY
                    fired = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!fired && e.rawY - downY > dp(34)) {
                        fired = true
                        openPanel(if (left) 0 else 1)
                    }
                }
            }
            true
        }
        val w = (resources.displayMetrics.widthPixels * 0.36f).toInt()
        val lp = WindowManager.LayoutParams(
            w, dp(20),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or (if (left) Gravity.LEFT else Gravity.RIGHT)
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try {
            wm.addView(v, lp)
            if (left) stripL = v else stripR = v
        } catch (e: Exception) {
        }
    }

    // ---- panels -----------------------------------------------------------

    private fun openPanel(kind: Int) {
        if (panelRoot != null) return
        closing = false
        val root = FrameLayout(this)
        val dim = View(this)
        dim.setBackgroundColor(Color.BLACK)
        dim.alpha = 0f
        dim.setOnClickListener { closePanel() }
        root.addView(dim, FrameLayout.LayoutParams(MP, MP))

        val content: View = if (kind == 0) {
            Panels.notificationCentre(this) { closePanel() }
        } else {
            Panels.controlCentre(this) { closePanel() }
        }
        val ch = if (kind == 0) (resources.displayMetrics.heightPixels * 0.88f).toInt() else WC
        root.addView(content, FrameLayout.LayoutParams(MP, ch, Gravity.TOP))

        val lp = WindowManager.LayoutParams(
            MP, MP,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            return
        }
        panelRoot = root
        panelContent = content
        panelDim = dim
        content.visibility = View.INVISIBLE
        content.post {
            content.translationY = -content.height.toFloat()
            content.visibility = View.VISIBLE
            content.animate().translationY(0f).setDuration(300).setInterpolator(DecelerateInterpolator(1.4f)).start()
        }
        dim.animate().alpha(0.55f).setDuration(280).start()
    }

    private fun closePanel() {
        val root = panelRoot ?: return
        if (closing) return
        closing = true
        panelDim?.animate()?.alpha(0f)?.setDuration(220)?.start()
        val content = panelContent
        if (content != null) {
            content.animate().translationY(-content.height.toFloat()).setDuration(240)
                .withEndAction { removePanel(root) }.start()
        } else {
            removePanel(root)
        }
    }

    private fun removePanel(root: View) {
        try {
            wm.removeView(root)
        } catch (e: Exception) {
        }
        if (panelRoot === root) {
            panelRoot = null
            panelContent = null
            panelDim = null
        }
        closing = false
    }

    // ---- lock screen ------------------------------------------------------

    private fun launchLock() {
        try {
            val i = Intent(this, LockActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            startActivity(i)
        } catch (e: Exception) {
        }
    }
}
