package com.hogwarts.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** The app drawer: rises with a 3D tilt, staggers icons in, and has an "Accio" search box. */
class DrawerView(ctx: Context, private val host: HomeActivity) : FrameLayout(ctx) {
    private val search = EditText(ctx)
    private val rv = RecyclerView(ctx)
    private val col = LinearLayout(ctx)
    private var shown: List<AppItem> = emptyList()
    private var animateIn = false
    private val adapter = Adapter()

    var isOpen = false
        private set

    private class VH(v: View) : RecyclerView.ViewHolder(v)

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = shown.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val c = parent.context
            val f = FrameLayout(c)
            f.layoutParams = RecyclerView.LayoutParams(MP, c.dp(104))
            val cell = AppCell(c, 58, true)
            cell.setOnClickListener { host.launch(it, cell.item) }
            cell.setOnLongClickListener {
                host.appMenu(it, cell.item)
                true
            }
            f.addView(cell, FrameLayout.LayoutParams(WC, WC, Gravity.CENTER))
            return VH(f)
        }

        override fun onBindViewHolder(vh: VH, position: Int) {
            val f = vh.itemView as FrameLayout
            val cell = f.getChildAt(0) as AppCell
            cell.bind(shown[position])
            f.animate().cancel()
            if (animateIn && position < 28) {
                f.alpha = 0f
                f.translationY = 70f
                f.animate().alpha(1f).translationY(0f).setStartDelay(position * 14L).setDuration(300).start()
            } else {
                f.alpha = 1f
                f.translationY = 0f
            }
        }
    }

    init {
        visibility = View.INVISIBLE
        val bg = GradientDrawable()
        bg.setColor(Color.argb(240, 4, 7, 20))
        val r = ctx.dpf(28f)
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        bg.setStroke(ctx.dp(1), Ui.alpha(House.glow(), 70))
        background = bg
        isClickable = true

        col.orientation = LinearLayout.VERTICAL
        addView(col, FrameLayout.LayoutParams(MP, MP))

        val handle = FrameLayout(ctx)
        val bar = View(ctx)
        val bb = GradientDrawable()
        bb.setColor(Color.argb(140, 255, 255, 255))
        bb.cornerRadius = ctx.dpf(3f)
        bar.background = bb
        handle.addView(bar, FrameLayout.LayoutParams(ctx.dp(46), ctx.dp(5), Gravity.CENTER))
        var dy0 = 0f
        var fired = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dy0 = e.rawY
                    fired = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!fired && e.rawY - dy0 > ctx.dp(40)) {
                        fired = true
                        close()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!fired && Math.abs(e.rawY - dy0) < ctx.dp(8)) close()
                }
            }
            true
        }
        col.addView(handle, LinearLayout.LayoutParams(MP, ctx.dp(30)))

        search.hint = "Accio\u2026 search the castle"
        search.setTextColor(Color.WHITE)
        search.setHintTextColor(Color.parseColor("#8E93AD"))
        search.textSize = 16f
        search.typeface = Ui.serif
        search.isSingleLine = true
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.background = Ui.glass(ctx, 24f, 150, 100)
        search.setPadding(ctx.dp(18), ctx.dp(12), ctx.dp(18), ctx.dp(12))
        val slp = LinearLayout.LayoutParams(MP, WC)
        slp.leftMargin = ctx.dp(18)
        slp.rightMargin = ctx.dp(18)
        slp.topMargin = ctx.dp(4)
        col.addView(search, slp)

        rv.layoutManager = GridLayoutManager(ctx, 4)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.setPadding(ctx.dp(6), ctx.dp(10), ctx.dp(6), ctx.dp(24))
        rv.overScrollMode = View.OVER_SCROLL_NEVER
        col.addView(rv, LinearLayout.LayoutParams(MP, 0, 1f))

        search.doAfterTextChanged { applyFilter(it?.toString() ?: "") }
        search.setOnEditorActionListener { _, _, _ ->
            val first = shown.firstOrNull()
            if (first != null) host.launchPlain(first)
            true
        }
    }

    fun setInsets(top: Int, bottom: Int) {
        col.setPadding(0, top + context.dp(4), 0, bottom)
    }

    fun refreshApps() {
        applyFilter(search.text.toString())
    }

    private fun applyFilter(q: String) {
        val s = q.trim().lowercase()
        shown = if (s.isEmpty()) AppRepo.apps else AppRepo.apps.filter { it.label.lowercase().contains(s) }
        adapter.notifyDataSetChanged()
    }

    fun focusSearch() {
        search.requestFocus()
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(search, 0)
    }

    fun open() {
        if (isOpen) return
        isOpen = true
        search.setText("")
        animateIn = true
        applyFilter("")
        visibility = View.VISIBLE
        pivotX = width / 2f
        pivotY = height.toFloat()
        cameraDistance = resources.displayMetrics.density * 9000f
        translationY = height * 0.55f
        rotationX = 14f
        alpha = 0f
        animate().translationY(0f).rotationX(0f).alpha(1f).setDuration(380)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
        postDelayed({ animateIn = false }, 700)
    }

    fun close() {
        if (!isOpen) return
        isOpen = false
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
        search.clearFocus()
        animate().translationY(height * 0.55f).rotationX(10f).alpha(0f).setDuration(260)
            .withEndAction { visibility = View.INVISIBLE }.start()
    }
}
