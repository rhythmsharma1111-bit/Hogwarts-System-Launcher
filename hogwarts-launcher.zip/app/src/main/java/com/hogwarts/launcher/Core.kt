package com.hogwarts.launcher

import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import java.util.Calendar
import java.util.Date
import kotlin.math.abs

const val MP = ViewGroup.LayoutParams.MATCH_PARENT
const val WC = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

class HogwartsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        sp = c.applicationContext.getSharedPreferences("hogwarts_prefs", Context.MODE_PRIVATE)
    }

    var house: Int
        get() = sp.getInt("house", -1)
        set(v) { sp.edit().putInt("house", v).apply() }
    var lockEnabled: Boolean
        get() = sp.getBoolean("lock", true)
        set(v) { sp.edit().putBoolean("lock", v).apply() }
    var islandIdle: Boolean
        get() = sp.getBoolean("idle", true)
        set(v) { sp.edit().putBoolean("idle", v).apply() }
    var strips: Boolean
        get() = sp.getBoolean("strips", true)
        set(v) { sp.edit().putBoolean("strips", v).apply() }
    var islandY: Int
        get() = sp.getInt("islandY", 8)
        set(v) { sp.edit().putInt("islandY", v).apply() }
    var tilt: Int
        get() = sp.getInt("tilt", 60)
        set(v) { sp.edit().putInt("tilt", v).apply() }
    var dockInit: Boolean
        get() = sp.getBoolean("dockInit", false)
        set(v) { sp.edit().putBoolean("dockInit", v).apply() }

    fun list(key: String): MutableList<String> {
        val s = sp.getString(key, "") ?: ""
        return if (s.isEmpty()) ArrayList<String>() else ArrayList<String>(s.split("\n"))
    }

    fun putList(key: String, l: List<String>) {
        sp.edit().putString(key, l.joinToString("\n")).apply()
    }
}

object House {
    val names = arrayOf("Gryffindor", "Slytherin", "Ravenclaw", "Hufflepuff")
    val mottos = arrayOf(
        "Daring, nerve and chivalry",
        "Ambition and cunning",
        "Wit and learning",
        "Loyalty and hard work"
    )
    private val glows = intArrayOf(
        Color.parseColor("#FFC857"), Color.parseColor("#5DE08A"),
        Color.parseColor("#6FA8FF"), Color.parseColor("#FFE066")
    )
    private val deeps = intArrayOf(
        Color.parseColor("#8E1B1B"), Color.parseColor("#14532D"),
        Color.parseColor("#12285C"), Color.parseColor("#5C4A00")
    )

    fun idx(): Int = Prefs.house.coerceIn(0, 3)
    fun glow(): Int = glows[idx()]
    fun deep(): Int = deeps[idx()]
    fun name(): String = names[idx()]
    fun glowOf(i: Int): Int = glows[i.coerceIn(0, 3)]
}

object Fmt {
    fun time(ctx: Context): String {
        val pat = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"
        return DateFormat.format(pat, Date()).toString()
    }

    fun date(): String = DateFormat.format("EEEE, d MMMM", Date()).toString()
}

object Spells {
    private val list = arrayOf(
        "Lumos" to "Conjures a beam of light at the wand tip.",
        "Nox" to "Puts out the light made by Lumos.",
        "Accio" to "Summons an object straight to the caster.",
        "Alohomora" to "Unlocks doors and windows.",
        "Wingardium Leviosa" to "Makes objects float and fly.",
        "Expelliarmus" to "Disarms an opponent.",
        "Expecto Patronum" to "Conjures a silver guardian.",
        "Riddikulus" to "Turns a boggart into something funny.",
        "Reparo" to "Mends broken objects.",
        "Incendio" to "Conjures flames.",
        "Aguamenti" to "Conjures a clean jet of water.",
        "Revelio" to "Reveals hidden things."
    )

    fun today(): Pair<String, String> {
        val d = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        return list[d % list.size]
    }
}

object Ui {
    val serif: Typeface = Typeface.create("serif", Typeface.NORMAL)
    val serifBold: Typeface = Typeface.create("serif", Typeface.BOLD)
    val serifItalic: Typeface = Typeface.create("serif", Typeface.ITALIC)

    fun alpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    fun mix(a: Int, b: Int, f: Float): Int {
        val t = f.coerceIn(0f, 1f)
        return Color.argb(
            (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt(),
            (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        )
    }

    fun glass(ctx: Context, radiusDp: Float, fill: Int = 150, stroke: Int = 90): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.argb(fill, 14, 18, 40))
        g.cornerRadius = ctx.dpf(radiusDp)
        g.setStroke(ctx.dp(1), alpha(House.glow(), stroke))
        return g
    }

    fun text(ctx: Context, s: String, sp: Float, color: Int = Color.WHITE, face: Typeface? = null): TextView {
        val t = TextView(ctx)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (face != null) t.typeface = face
        return t
    }

    fun statusBarHeight(ctx: Context): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else ctx.dp(28)
    }
}

/** Smoothed phone tilt in -1..1 used for 3D parallax. */
object Tilt : SensorEventListener {
    var x = 0f
    var y = 0f
    private var bx = 0f
    private var by = 0f
    private var primed = false
    private var started = 0
    private var sm: SensorManager? = null
    private val views = ArrayList<View>()

    fun register(v: View) {
        if (!views.contains(v)) views.add(v)
    }

    fun unregister(v: View) {
        views.remove(v)
    }

    fun start(ctx: Context) {
        started++
        if (started == 1) {
            primed = false
            val m = ctx.applicationContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            sm = m
            val s = m.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (s != null) m.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        if (started > 0) started--
        if (started == 0) sm?.unregisterListener(this)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val ax = e.values[0] / 9.81f
        val az = e.values[2] / 9.81f
        if (!primed) {
            bx = ax
            by = az
            primed = true
        }
        bx += (ax - bx) * 0.004f
        by += (az - by) * 0.004f
        val k = Prefs.tilt / 100f * 2.4f
        val tx = ((ax - bx) * k).coerceIn(-1f, 1f)
        val ty = ((az - by) * k).coerceIn(-1f, 1f)
        val nx = x + (tx - x) * 0.15f
        val ny = y + (ty - y) * 0.15f
        if (abs(nx - x) > 0.002f || abs(ny - y) > 0.002f) {
            x = nx
            y = ny
            for (v in views) v.invalidate()
        }
    }
}

object Torch {
    var on = false

    fun toggle(ctx: Context) {
        set(ctx, !on)
    }

    fun set(ctx: Context, v: Boolean) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            cm.setTorchMode(id, v)
            on = v
        } catch (e: Exception) {
        }
    }
}

class NotifItem(
    val key: String,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long,
    val icon: Bitmap?,
    val pi: PendingIntent?
)

/** Tiny in-process event bus shared by the listener, the island, the panels and the lock screen. */
object Hub {
    val notifs = ArrayList<NotifItem>()
    var listener: HogwartsNotificationListener? = null
    var media: MediaController? = null

    private val notifL = ArrayList<() -> Unit>()
    private val postedL = ArrayList<(NotifItem) -> Unit>()
    private val mediaL = ArrayList<() -> Unit>()

    fun onNotifs(l: () -> Unit) { if (!notifL.contains(l)) notifL.add(l) }
    fun offNotifs(l: () -> Unit) { notifL.remove(l) }
    fun onPosted(l: (NotifItem) -> Unit) { if (!postedL.contains(l)) postedL.add(l) }
    fun offPosted(l: (NotifItem) -> Unit) { postedL.remove(l) }
    fun onMedia(l: () -> Unit) { if (!mediaL.contains(l)) mediaL.add(l) }
    fun offMedia(l: () -> Unit) { mediaL.remove(l) }

    fun fireNotifs() { for (l in ArrayList(notifL)) l() }
    fun firePosted(n: NotifItem) { for (l in ArrayList(postedL)) l(n) }
    fun fireMedia() { for (l in ArrayList(mediaL)) l() }

    fun isPlaying(): Boolean = media?.playbackState?.state == PlaybackState.STATE_PLAYING
    fun mediaTitle(): String = media?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Unknown track"
    fun mediaArtist(): String = media?.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""

    fun dismiss(key: String) {
        try { listener?.cancelNotification(key) } catch (e: Exception) { }
        notifs.removeAll { it.key == key }
        fireNotifs()
    }

    fun clearAll() {
        try { listener?.cancelAllNotifications() } catch (e: Exception) { }
        notifs.clear()
        fireNotifs()
    }
}
