package com.hogwarts.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import java.util.Calendar
import kotlin.math.sin
import kotlin.random.Random

/**
 * Procedural, code-made 3D night scene of a castle: layered parallax driven by phone tilt,
 * twinkling stars, drifting clouds, floating candles, glowing windows and magic dust.
 */
class SceneView(ctx: Context) : View(ctx) {
    var running = false
        set(v) {
            field = v
            if (v) postInvalidateOnAnimation()
        }
    var lockMode = false
        set(v) {
            field = v
            overlayTop = null
        }

    private class Star(val x: Float, val y: Float, val r: Float, val ph: Float, val sp: Float)
    private class Win(val x: Float, val y: Float, val w: Float, val h: Float, val ph: Float, val sp: Float)
    private class Candle(val x: Float, val y: Float, val ph: Float, val sp: Float)
    private class Mote(var x: Float, var y: Float, val vx: Float, val vy: Float, val r: Float, val ph: Float)
    private class Cloud(var x: Float, val y: Float, val w: Float, val v: Float)

    private val rnd = Random(11)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val d = ctx.resources.displayMetrics.density
    private val maxShift = 14f * d
    private val t0 = SystemClock.uptimeMillis()
    private var lastT = t0

    private var stars = ArrayList<Star>()
    private var wins = ArrayList<Win>()
    private var candles = ArrayList<Candle>()
    private var motes = ArrayList<Mote>()
    private var clouds = ArrayList<Cloud>()
    private val castle = Path()
    private val cliff = Path()
    private val mount = Path()
    private val forest = Path()

    private var skyShader: Shader? = null
    private var overlayTop: Shader? = null
    private var overlayBot: Shader? = null
    private var hallGlow: Shader? = null
    private var night = 1f
    private var day = 0f
    private var lastSky = 0L
    private var glow = House.glow()

    private fun c(s: String): Int = Color.parseColor(s)

    private val hrs = floatArrayOf(0f, 5f, 7f, 12f, 17f, 19f, 21f, 24f)
    private val tops = intArrayOf(c("#050818"), c("#0B1030"), c("#3A4A8C"), c("#3F6AA8"), c("#3B3F7A"), c("#1C1850"), c("#070A1E"), c("#050818"))
    private val bots = intArrayOf(c("#1B2350"), c("#2B3A7A"), c("#F0A070"), c("#8EB4DE"), c("#E08A5A"), c("#7A3E7E"), c("#1A2250"), c("#1B2350"))
    private val nights = floatArrayOf(1f, 0.8f, 0.2f, 0f, 0.1f, 0.6f, 1f, 1f)

    private fun rectCW(p: Path, l: Float, t: Float, r: Float, b: Float) {
        p.moveTo(l, t)
        p.lineTo(r, t)
        p.lineTo(r, b)
        p.lineTo(l, b)
        p.close()
    }

    private fun triCW(p: Path, xl: Float, xr: Float, yb: Float, xa: Float, ya: Float) {
        p.moveTo(xl, yb)
        p.lineTo(xa, ya)
        p.lineTo(xr, yb)
        p.close()
    }

    private fun poly(p: Path, W: Float, H: Float, pts: FloatArray) {
        var k = 0
        while (k < pts.size) {
            p.lineTo(pts[k] * W, pts[k + 1] * H)
            k += 2
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val W = w.toFloat()
        val H = h.toFloat()
        glow = House.glow()

        stars = ArrayList()
        for (i in 0 until 110) {
            stars.add(Star(rnd.nextFloat() * W, rnd.nextFloat() * H * 0.62f, 0.5f + rnd.nextFloat() * 1.3f, rnd.nextFloat() * 6.28f, 0.8f + rnd.nextFloat() * 2f))
        }
        clouds = ArrayList()
        for (i in 0 until 5) {
            clouds.add(Cloud(rnd.nextFloat() * W, H * (0.10f + rnd.nextFloat() * 0.35f), W * (0.35f + rnd.nextFloat() * 0.35f), 4f + rnd.nextFloat() * 8f))
        }
        candles = ArrayList()
        for (i in 0 until 14) {
            candles.add(Candle(rnd.nextFloat() * W, H * (0.08f + rnd.nextFloat() * 0.40f), rnd.nextFloat() * 6.28f, 0.6f + rnd.nextFloat() * 0.9f))
        }
        motes = ArrayList()
        for (i in 0 until 34) {
            motes.add(Mote(rnd.nextFloat() * W, rnd.nextFloat() * H, (rnd.nextFloat() - 0.5f) * 10f, -4f - rnd.nextFloat() * 10f, 1f + rnd.nextFloat() * 2f, rnd.nextFloat() * 6.28f))
        }

        mount.reset()
        mount.moveTo(-0.1f * W, 0.9f * H)
        poly(mount, W, H, floatArrayOf(-0.05f, 0.64f, 0.10f, 0.58f, 0.20f, 0.69f, 0.32f, 0.57f, 0.46f, 0.70f, 0.60f, 0.60f, 0.74f, 0.71f, 0.88f, 0.56f, 1.05f, 0.68f))
        mount.lineTo(1.1f * W, 0.9f * H)
        mount.close()

        cliff.reset()
        cliff.moveTo(-0.1f * W, H)
        poly(cliff, W, H, floatArrayOf(-0.1f, 0.84f, 0.05f, 0.805f, 0.12f, 0.83f, 0.25f, 0.795f, 0.40f, 0.815f, 0.50f, 0.80f, 0.65f, 0.815f, 0.78f, 0.795f, 0.90f, 0.83f, 1.1f, 0.81f))
        cliff.lineTo(1.1f * W, H)
        cliff.close()

        castle.reset()
        wins = ArrayList()
        val base = 0.84f * H
        rectCW(castle, 0.22f * W, 0.68f * H, 0.78f * W, base)
        triCW(castle, 0.20f * W, 0.80f * W, 0.68f * H, 0.5f * W, 0.625f * H)
        rectCW(castle, -0.1f * W, 0.745f * H, 0.22f * W, 0.757f * H)
        for (px in floatArrayOf(-0.02f, 0.06f, 0.14f)) {
            rectCW(castle, px * W - 0.008f * W, 0.757f * H, px * W + 0.008f * W, base)
        }
        val towers = arrayOf(
            floatArrayOf(0.50f, 0.070f, 0.38f, 0.100f),
            floatArrayOf(0.31f, 0.060f, 0.49f, 0.075f),
            floatArrayOf(0.69f, 0.065f, 0.45f, 0.085f),
            floatArrayOf(0.19f, 0.050f, 0.56f, 0.060f),
            floatArrayOf(0.83f, 0.052f, 0.57f, 0.065f),
            floatArrayOf(0.405f, 0.040f, 0.55f, 0.055f),
            floatArrayOf(0.595f, 0.044f, 0.52f, 0.058f),
            floatArrayOf(0.09f, 0.045f, 0.64f, 0.050f),
            floatArrayOf(0.93f, 0.045f, 0.63f, 0.050f)
        )
        for (t in towers) {
            val cx = t[0] * W
            val bw = t[1] * W
            val top = t[2] * H
            val roof = t[3] * H
            rectCW(castle, cx - bw / 2f, top, cx + bw / 2f, base)
            rectCW(castle, cx - bw * 0.62f, top - bw * 0.10f, cx + bw * 0.62f, top)
            triCW(castle, cx - bw * 0.68f, cx + bw * 0.68f, top - bw * 0.10f, cx, top - bw * 0.10f - roof)
            val cols = if (t[1] > 0.055f) 2 else 1
            var y = top + bw * 0.5f
            while (y < 0.76f * H) {
                for (ci in 1..cols) {
                    if (rnd.nextFloat() < 0.62f) {
                        val x = cx - bw / 2f + bw * ci / (cols + 1) - bw * 0.07f
                        wins.add(Win(x, y, bw * 0.14f, bw * 0.24f, rnd.nextFloat() * 6.28f, 0.6f + rnd.nextFloat() * 1.6f))
                    }
                }
                y += bw * 0.9f
            }
        }
        var hx = 0.26f * W
        while (hx < 0.74f * W) {
            for (r in 0..1) {
                if (rnd.nextFloat() < 0.75f) {
                    wins.add(Win(hx, (0.705f + r * 0.045f) * H, 0.016f * W, 0.022f * H, rnd.nextFloat() * 6.28f, 0.6f + rnd.nextFloat() * 1.6f))
                }
            }
            hx += 0.04f * W
        }

        forest.reset()
        forest.moveTo(-0.1f * W, 1.1f * H)
        val n = 24
        val yb = 0.935f * H
        for (i in -1..n) {
            val x = i * W / n + (rnd.nextFloat() - 0.5f) * (W / n) * 0.5f
            val th = H * (0.035f + rnd.nextFloat() * 0.06f)
            val tw = W / n * 0.75f
            forest.lineTo(x - tw, yb)
            forest.lineTo(x, yb - th)
            forest.lineTo(x + tw, yb)
        }
        forest.lineTo(1.1f * W, 1.1f * H)
        forest.close()

        hallGlow = RadialGradient(W * 0.5f, H * 0.72f, W * 0.55f, Color.argb(70, 255, 190, 110), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        overlayTop = null
        updateSky(true)
    }

    private fun makeOverlays() {
        val W = width.toFloat()
        val H = height.toFloat()
        overlayTop = LinearGradient(0f, 0f, 0f, H * 0.38f, Color.argb(if (lockMode) 70 else 120, 0, 0, 0), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        overlayBot = LinearGradient(0f, H * 0.72f, 0f, H, Color.TRANSPARENT, Color.argb(if (lockMode) 90 else 150, 0, 0, 0), Shader.TileMode.CLAMP)
    }

    private fun updateSky(force: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (!force && now - lastSky < 20000) return
        lastSky = now
        val cal = Calendar.getInstance()
        val hr = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60f
        var i = 0
        while (i < hrs.size - 2 && hr >= hrs[i + 1]) i++
        val f = (hr - hrs[i]) / (hrs[i + 1] - hrs[i])
        val top = Ui.mix(tops[i], tops[i + 1], f)
        val bot = Ui.mix(bots[i], bots[i + 1], f)
        night = nights[i] + (nights[i + 1] - nights[i]) * f
        day = 1f - night
        if (width > 0) skyShader = LinearGradient(0f, 0f, 0f, height * 0.85f, top, bot, Shader.TileMode.CLAMP)
    }

    override fun onDraw(cv: Canvas) {
        val W = width.toFloat()
        val H = height.toFloat()
        if (W <= 0f) return
        updateSky(false)
        if (overlayTop == null) makeOverlays()
        val now = SystemClock.uptimeMillis()
        val tt = (now - t0) / 1000f
        val dt = ((now - lastT) / 1000f).coerceAtMost(0.1f)
        lastT = now
        val tx = Tilt.x
        val ty = Tilt.y

        paint.shader = skyShader
        paint.color = Color.BLACK
        cv.drawRect(0f, 0f, W, H, paint)
        paint.shader = null

        if (night > 0.02f) {
            cv.save()
            cv.translate(tx * 0.05f * maxShift, ty * 0.03f * maxShift)
            for (i in 0 until stars.size) {
                val s = stars[i]
                val a = (0.35f + 0.65f * (0.5f + 0.5f * sin(tt * s.sp + s.ph))) * night
                paint.color = Color.argb((a * 255).toInt(), 255, 250, 235)
                cv.drawCircle(s.x, s.y, s.r * d, paint)
            }
            cv.restore()

            val mx = W * 0.78f + tx * 0.1f * maxShift
            val my = H * 0.15f + ty * 0.06f * maxShift
            val mr = W * 0.045f
            for (i in 3 downTo 1) {
                paint.color = Color.argb((16 * night).toInt(), 200, 215, 255)
                cv.drawCircle(mx, my, mr * (1f + i * 0.8f), paint)
            }
            paint.color = Color.argb((255 * night).toInt(), 244, 241, 230)
            cv.drawCircle(mx, my, mr, paint)
            paint.color = Color.argb((60 * night).toInt(), 190, 190, 175)
            cv.drawCircle(mx - mr * 0.3f, my - mr * 0.2f, mr * 0.22f, paint)
            cv.drawCircle(mx + mr * 0.25f, my + mr * 0.3f, mr * 0.16f, paint)
        }

        val cloudA = (26 + 40 * day).toInt()
        for (i in 0 until clouds.size) {
            val cl = clouds[i]
            cl.x += cl.v * d * dt
            if (cl.x > W) cl.x = -cl.w
            cv.save()
            cv.translate(tx * 0.2f * maxShift, 0f)
            paint.color = Color.argb(cloudA, 190, 200, 235)
            rect.set(cl.x, cl.y, cl.x + cl.w, cl.y + cl.w * 0.16f)
            cv.drawOval(rect, paint)
            rect.set(cl.x + cl.w * 0.2f, cl.y - cl.w * 0.05f, cl.x + cl.w * 0.7f, cl.y + cl.w * 0.12f)
            cv.drawOval(rect, paint)
            cv.restore()
        }

        cv.save()
        cv.translate(tx * 0.35f * maxShift, ty * 0.2f * maxShift)
        paint.color = Ui.mix(c("#141B40"), c("#5D7DA8"), day)
        cv.drawPath(mount, paint)
        cv.restore()

        cv.save()
        cv.translate(tx * 0.6f * maxShift, ty * 0.35f * maxShift)
        paint.shader = hallGlow
        paint.alpha = (255 * night.coerceAtLeast(0.25f)).toInt()
        cv.drawRect(0f, H * 0.3f, W, H, paint)
        paint.shader = null
        paint.color = Ui.mix(c("#070B1C"), c("#1B2748"), day * 0.7f)
        cv.drawPath(castle, paint)
        val wa = 0.35f + 0.65f * night
        for (i in 0 until wins.size) {
            val wn = wins[i]
            val fl = 0.55f + 0.45f * sin(tt * wn.sp + wn.ph)
            val a = (255 * fl * wa).toInt()
            paint.color = Color.argb((a * 0.25f).toInt(), 255, 200, 110)
            cv.drawRect(wn.x - d, wn.y - d, wn.x + wn.w + d, wn.y + wn.h + d, paint)
            paint.color = Color.argb(a, 255, 214, 130)
            cv.drawRect(wn.x, wn.y, wn.x + wn.w, wn.y + wn.h, paint)
        }
        cv.restore()

        cv.save()
        cv.translate(tx * 0.7f * maxShift, ty * 0.4f * maxShift)
        paint.color = Ui.mix(c("#050810"), c("#101A28"), day * 0.7f)
        cv.drawPath(cliff, paint)
        cv.restore()

        cv.save()
        cv.translate(tx * 1.0f * maxShift, ty * 0.6f * maxShift)
        paint.color = Ui.mix(c("#03060D"), c("#0F1A24"), day * 0.7f)
        cv.drawPath(forest, paint)
        cv.restore()

        val ca = if (lockMode) 1f else 0.6f
        val cn = if (lockMode) candles.size else 8
        cv.save()
        cv.translate(tx * 1.4f * maxShift, ty * 0.9f * maxShift)
        for (i in 0 until cn) {
            val cd = candles[i]
            val by = cd.y + sin(tt * cd.sp + cd.ph) * 6f * d
            val bx = cd.x + sin(tt * cd.sp * 0.7f + cd.ph) * 3f * d
            val fl = 0.8f + 0.2f * sin(tt * 9f + cd.ph * 3f)
            paint.color = Color.argb((22 * ca * fl).toInt(), 255, 190, 90)
            cv.drawCircle(bx, by - 8f * d, 22f * d, paint)
            paint.color = Color.argb((40 * ca * fl).toInt(), 255, 200, 110)
            cv.drawCircle(bx, by - 8f * d, 11f * d, paint)
            paint.color = Color.argb((235 * ca).toInt(), 238, 228, 196)
            rect.set(bx - 1.8f * d, by - 2f * d, bx + 1.8f * d, by + 12f * d)
            cv.drawRoundRect(rect, d, d, paint)
            paint.color = Color.argb((255 * ca).toInt(), 255, 176, 66)
            rect.set(bx - 2f * d, by - 9f * d, bx + 2f * d, by - 1.5f * d)
            cv.drawOval(rect, paint)
        }
        cv.restore()

        for (i in 0 until motes.size) {
            val m = motes[i]
            m.x += m.vx * d * dt
            m.y += m.vy * d * dt
            if (m.y < -10f) {
                m.y = H + 10f
                m.x = rnd.nextFloat() * W
            }
            if (m.x < -10f) m.x = W + 10f
            if (m.x > W + 10f) m.x = -10f
            val a = 0.35f + 0.65f * (0.5f + 0.5f * sin(tt * 1.8f + m.ph))
            val px = m.x + tx * 1.8f * maxShift
            paint.color = Ui.alpha(glow, (70 * a).toInt())
            cv.drawCircle(px, m.y, m.r * 3.2f * d, paint)
            paint.color = Ui.alpha(glow, (230 * a).toInt())
            cv.drawCircle(px, m.y, m.r * d, paint)
        }

        paint.shader = overlayTop
        cv.drawRect(0f, 0f, W, H * 0.38f, paint)
        paint.shader = overlayBot
        cv.drawRect(0f, H * 0.72f, W, H, paint)
        paint.shader = null

        if (running) postInvalidateDelayed(16)
    }
}
