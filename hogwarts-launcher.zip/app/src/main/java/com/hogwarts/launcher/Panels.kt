package com.hogwarts.launcher

import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.provider.Settings
import android.text.TextUtils
import android.text.format.DateUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class SwipeToDismiss(private val onDismiss: () -> Unit, private val onClick: () -> Unit) : View.OnTouchListener {
    private var x0 = 0f
    private var y0 = 0f
    private var dragging = false

    override fun onTouch(v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                x0 = e.rawX
                y0 = e.rawY
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - x0
                val dy = e.rawY - y0
                if (!dragging && abs(dx) > 24f && abs(dx) > abs(dy)) {
                    dragging = true
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging) {
                    v.translationX = dx
                    v.alpha = 1f - min(1f, abs(dx) / max(1, v.width))
                }
            }
            MotionEvent.ACTION_UP -> {
                val dx = e.rawX - x0
                if (dragging) {
                    if (abs(dx) > v.width * 0.35f) {
                        val to = if (dx > 0) v.width.toFloat() else -v.width.toFloat()
                        v.animate().translationX(to).alpha(0f).setDuration(160).withEndAction { onDismiss() }.start()
                    } else {
                        v.animate().translationX(0f).alpha(1f).setDuration(160).start()
                    }
                } else if (abs(dx) < 24f && abs(e.rawY - y0) < 24f) {
                    onClick()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                v.animate().translationX(0f).alpha(1f).setDuration(120).start()
            }
        }
        return true
    }
}

object Panels {
    private fun sheet(ctx: Context): GradientDrawable {
        val g = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(246, 10, 14, 34), Color.argb(246, 26, 20, 54))
        )
        val r = ctx.dpf(30f)
        g.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        g.setStroke(ctx.dp(1), Ui.alpha(House.glow(), 90))
        return g
    }

    private fun handleBar(ctx: Context, close: () -> Unit): View {
        val box = LinearLayout(ctx)
        box.gravity = Gravity.CENTER
        val bar = View(ctx)
        val g = GradientDrawable()
        g.setColor(Color.argb(130, 255, 255, 255))
        g.cornerRadius = ctx.dpf(3f)
        bar.background = g
        box.addView(bar, LinearLayout.LayoutParams(ctx.dp(46), ctx.dp(5)))
        var downY = 0f
        var fired = false
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.rawY
                    fired = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!fired && downY - e.rawY > ctx.dp(24)) {
                        fired = true
                        close()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!fired && abs(downY - e.rawY) < ctx.dp(8)) close()
                }
            }
            true
        }
        return box
    }

    private fun openIntent(ctx: Context, close: () -> Unit, i: Intent) {
        close()
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Couldn't open that screen", Toast.LENGTH_SHORT).show()
        }
    }

    private fun circleBg(ctx: Context, on: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        if (on) {
            g.setColor(Ui.alpha(House.glow(), 235))
        } else {
            g.setColor(Color.argb(150, 40, 46, 82))
            g.setStroke(ctx.dp(1), Color.argb(60, 255, 255, 255))
        }
        return g
    }

    // ------------------------------------------------------------------ control centre

    fun controlCentre(ctx: Context, close: () -> Unit): View {
        val glow = House.glow()
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.background = sheet(ctx)
        card.setPadding(ctx.dp(18), Ui.statusBarHeight(ctx) + ctx.dp(14), ctx.dp(18), ctx.dp(6))

        card.addView(Ui.text(ctx, "Enchantments", 22f, Color.WHITE, Ui.serifBold))
        card.addView(Ui.text(ctx, "House " + House.name() + " \u2726 " + Fmt.time(ctx), 12f, glow, Ui.serifItalic))

        val circles = ArrayList<Pair<TextView, () -> Boolean>>()
        fun refreshTiles() {
            for (p in circles) p.first.background = circleBg(ctx, p.second())
        }

        fun tile(emoji: String, name: String, state: () -> Boolean, tap: () -> Unit): View {
            val box = LinearLayout(ctx)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER_HORIZONTAL
            val cv = Ui.text(ctx, emoji, 24f)
            cv.gravity = Gravity.CENTER
            box.addView(cv, LinearLayout.LayoutParams(ctx.dp(58), ctx.dp(58)))
            val lb = Ui.text(ctx, name, 10.5f, Color.parseColor("#C9CCE0"))
            lb.gravity = Gravity.CENTER
            lb.maxLines = 1
            lb.ellipsize = TextUtils.TruncateAt.END
            val llp = LinearLayout.LayoutParams(WC, WC)
            llp.topMargin = ctx.dp(4)
            box.addView(lb, llp)
            circles.add(Pair(cv, state))
            box.setOnClickListener {
                tap()
                cv.postDelayed({ refreshTiles() }, 250)
            }
            return box
        }

        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val cr = ctx.contentResolver

        val row1 = LinearLayout(ctx)
        val row2 = LinearLayout(ctx)
        val rowLp = LinearLayout.LayoutParams(MP, WC)
        rowLp.topMargin = ctx.dp(14)

        fun add(row: LinearLayout, v: View) {
            row.addView(v, LinearLayout.LayoutParams(0, WC, 1f))
        }

        add(row1, tile("\uD83D\uDCF6", "Floo Network", {
            try {
                (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
            } catch (e: Exception) {
                false
            }
        }, { openIntent(ctx, close, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }))

        add(row1, tile("\uD83E\uDD89", "Owl Post", {
            try {
                ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
            } catch (e: Exception) {
                false
            }
        }, { openIntent(ctx, close, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }))

        add(row1, tile("\u2708\uFE0F", "Apparate", {
            Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        }, { openIntent(ctx, close, Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }))

        add(row1, tile("\uD83D\uDD26", "Lumos", { Torch.on }, { Torch.toggle(ctx) }))

        add(row2, tile("\uD83C\uDF19", "Nox", {
            nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        }, {
            if (nm.isNotificationPolicyAccessGranted) {
                val cur = nm.currentInterruptionFilter
                nm.setInterruptionFilter(
                    if (cur == NotificationManager.INTERRUPTION_FILTER_ALL) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                    else NotificationManager.INTERRUPTION_FILTER_ALL
                )
            } else {
                openIntent(ctx, close, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }))

        add(row2, tile("\uD83D\uDD04", "Revelio", {
            Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
        }, {
            if (Settings.System.canWrite(ctx)) {
                val cur = Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0)
                Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1 - cur)
            } else {
                openIntent(ctx, close, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            }
        }))

        add(row2, tile("\uD83D\uDDDD\uFE0F", "Alohomora", { false }, {
            openIntent(ctx, close, Intent(Settings.ACTION_SETTINGS))
        }))

        add(row2, tile("\uD83D\uDD12", "Colloportus", { false }, {
            close()
            HogwartsAccessibilityService.lockScreen()
        }))

        card.addView(row1, rowLp)
        card.addView(row2, LinearLayout.LayoutParams(rowLp))

        fun slider(emoji: String, max: Int, cur: Int, onChange: (Int) -> Unit): View {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = Ui.glass(ctx, 22f, 120, 60)
            row.setPadding(ctx.dp(16), ctx.dp(2), ctx.dp(16), ctx.dp(2))
            row.addView(Ui.text(ctx, emoji, 20f))
            val sb = SeekBar(ctx)
            sb.max = max
            sb.progress = cur
            sb.progressTintList = ColorStateList.valueOf(glow)
            sb.thumbTintList = ColorStateList.valueOf(Color.WHITE)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) onChange(p)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            row.addView(sb, LinearLayout.LayoutParams(0, ctx.dp(44), 1f))
            return row
        }

        val curB = try {
            Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) {
            128
        }
        val maxB = if (curB > 255) 2047 else 255
        var askedWrite = false
        val sLp = LinearLayout.LayoutParams(MP, WC)
        sLp.topMargin = ctx.dp(14)
        card.addView(slider("\u2600\uFE0F", maxB, curB) { p ->
            if (Settings.System.canWrite(ctx)) {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, max(p, maxB / 50))
            } else if (!askedWrite) {
                askedWrite = true
                openIntent(ctx, close, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            }
        }, sLp)

        val vLp = LinearLayout.LayoutParams(MP, WC)
        vLp.topMargin = ctx.dp(10)
        card.addView(
            slider(
                "\uD83D\uDD0A",
                am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                am.getStreamVolume(AudioManager.STREAM_MUSIC)
            ) { p -> am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0) }, vLp
        )

        // now playing
        val media = LinearLayout(ctx)
        media.orientation = LinearLayout.VERTICAL
        media.background = Ui.glass(ctx, 22f, 120, 60)
        media.setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(8))
        val mTitle = Ui.text(ctx, "", 15f, Color.WHITE, Ui.serifBold)
        mTitle.maxLines = 1
        mTitle.ellipsize = TextUtils.TruncateAt.END
        val mSub = Ui.text(ctx, "", 12f, Color.parseColor("#B8BCCF"))
        mSub.maxLines = 1
        mSub.ellipsize = TextUtils.TruncateAt.END
        media.addView(mTitle)
        media.addView(mSub)
        val ctrl = LinearLayout(ctx)
        ctrl.gravity = Gravity.CENTER
        val play = ImageView(ctx)
        fun mbtn(iv: ImageView, res: Int, act: () -> Unit) {
            iv.setImageResource(res)
            iv.setColorFilter(Color.WHITE)
            iv.setPadding(ctx.dp(12), ctx.dp(6), ctx.dp(12), ctx.dp(6))
            iv.setOnClickListener { act() }
            ctrl.addView(iv, LinearLayout.LayoutParams(ctx.dp(70), ctx.dp(42)))
        }
        mbtn(ImageView(ctx), android.R.drawable.ic_media_previous) { Hub.media?.transportControls?.skipToPrevious() }
        mbtn(play, android.R.drawable.ic_media_pause) {
            val mc = Hub.media
            if (mc != null) {
                if (Hub.isPlaying()) mc.transportControls.pause() else mc.transportControls.play()
            }
        }
        mbtn(ImageView(ctx), android.R.drawable.ic_media_next) { Hub.media?.transportControls?.skipToNext() }
        media.addView(ctrl, LinearLayout.LayoutParams(MP, WC))
        val mLp = LinearLayout.LayoutParams(MP, WC)
        mLp.topMargin = ctx.dp(10)
        card.addView(media, mLp)

        fun refreshMedia() {
            if (Hub.media == null) {
                mTitle.text = "Nothing playing"
                mSub.text = "The Great Hall is quiet"
                ctrl.visibility = View.GONE
            } else {
                mTitle.text = Hub.mediaTitle()
                mSub.text = Hub.mediaArtist()
                ctrl.visibility = View.VISIBLE
                play.setImageResource(if (Hub.isPlaying()) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
            }
        }

        val hb = handleBar(ctx, close)
        val hLp = LinearLayout.LayoutParams(MP, ctx.dp(34))
        hLp.topMargin = ctx.dp(6)
        card.addView(hb, hLp)

        val mediaL: () -> Unit = { refreshMedia() }
        card.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                Hub.onMedia(mediaL)
                refreshTiles()
                refreshMedia()
            }

            override fun onViewDetachedFromWindow(v: View) {
                Hub.offMedia(mediaL)
            }
        })
        return card
    }

    // ------------------------------------------------------------------ notification centre

    fun notificationCentre(ctx: Context, close: () -> Unit): View {
        val glow = House.glow()
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.background = sheet(ctx)
        card.setPadding(ctx.dp(16), Ui.statusBarHeight(ctx) + ctx.dp(14), ctx.dp(16), ctx.dp(4))

        val head = LinearLayout(ctx)
        head.gravity = Gravity.CENTER_VERTICAL
        val titles = LinearLayout(ctx)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(Ui.text(ctx, "Owl Post", 24f, Color.WHITE, Ui.serifBold))
        val countTv = Ui.text(ctx, "", 12f, glow, Ui.serifItalic)
        titles.addView(countTv)
        head.addView(titles, LinearLayout.LayoutParams(0, WC, 1f))
        val clear = Ui.text(ctx, "Clear all", 13f, Color.WHITE)
        clear.background = Ui.glass(ctx, 16f, 140, 110)
        clear.setPadding(ctx.dp(14), ctx.dp(7), ctx.dp(14), ctx.dp(7))
        clear.setOnClickListener { Hub.clearAll() }
        head.addView(clear, LinearLayout.LayoutParams(WC, WC))
        card.addView(head, LinearLayout.LayoutParams(MP, WC))

        val scroll = ScrollView(ctx)
        scroll.isVerticalScrollBarEnabled = false
        val list = LinearLayout(ctx)
        list.orientation = LinearLayout.VERTICAL
        scroll.addView(list, LinearLayout.LayoutParams(MP, WC))
        val sLp = LinearLayout.LayoutParams(MP, 0, 1f)
        sLp.topMargin = ctx.dp(12)
        card.addView(scroll, sLp)

        fun note(msg: String, action: (() -> Unit)?) {
            val t = Ui.text(ctx, msg, 14f, Color.parseColor("#C9CCE0"), Ui.serifItalic)
            t.gravity = Gravity.CENTER
            t.setPadding(ctx.dp(16), ctx.dp(28), ctx.dp(16), ctx.dp(28))
            if (action != null) {
                t.background = Ui.glass(ctx, 20f, 120, 80)
                t.setOnClickListener { action() }
            }
            list.addView(t, LinearLayout.LayoutParams(MP, WC))
        }

        fun render() {
            list.removeAllViews()
            val enabled = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
            if (!enabled) {
                countTv.text = "Owls can't find you yet"
                note("Tap here to let Hogwarts read your notifications", {
                    openIntent(ctx, close, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                })
                return
            }
            val items = ArrayList(Hub.notifs)
            countTv.text = if (items.isEmpty()) "All quiet in the owlery" else items.size.toString() + " letters waiting"
            if (items.isEmpty()) {
                note("No owls tonight \u2728", null)
                return
            }
            for (n in items) {
                val row = LinearLayout(ctx)
                row.orientation = LinearLayout.HORIZONTAL
                row.background = Ui.glass(ctx, 20f, 140, 70)
                row.setPadding(ctx.dp(12), ctx.dp(10), ctx.dp(12), ctx.dp(10))
                val iv = ImageView(ctx)
                if (n.icon != null) iv.setImageBitmap(n.icon)
                row.addView(iv, LinearLayout.LayoutParams(ctx.dp(36), ctx.dp(36)))
                val col = LinearLayout(ctx)
                col.orientation = LinearLayout.VERTICAL
                val whenText = DateUtils.getRelativeTimeSpanString(n.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS)
                col.addView(Ui.text(ctx, n.app + " \u00B7 " + whenText, 11f, glow))
                if (n.title.isNotEmpty()) {
                    val t = Ui.text(ctx, n.title, 14.5f, Color.WHITE, Typeface.DEFAULT_BOLD)
                    t.maxLines = 1
                    t.ellipsize = TextUtils.TruncateAt.END
                    col.addView(t)
                }
                if (n.text.isNotEmpty()) {
                    val t = Ui.text(ctx, n.text, 13f, Color.parseColor("#C9CCE0"))
                    t.maxLines = 3
                    t.ellipsize = TextUtils.TruncateAt.END
                    col.addView(t)
                }
                val clp = LinearLayout.LayoutParams(0, WC, 1f)
                clp.leftMargin = ctx.dp(10)
                row.addView(col, clp)
                row.setOnTouchListener(SwipeToDismiss({ Hub.dismiss(n.key) }, {
                    try {
                        n.pi?.send()
                    } catch (e: Exception) {
                        val li = ctx.packageManager.getLaunchIntentForPackage(n.pkg)
                        if (li != null) {
                            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            try { ctx.startActivity(li) } catch (e2: Exception) { }
                        }
                    }
                    close()
                }))
                val rlp = LinearLayout.LayoutParams(MP, WC)
                rlp.bottomMargin = ctx.dp(8)
                list.addView(row, rlp)
            }
        }

        val hb = handleBar(ctx, close)
        val hLp = LinearLayout.LayoutParams(MP, ctx.dp(34))
        card.addView(hb, hLp)

        val notifL: () -> Unit = { render() }
        card.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                Hub.onNotifs(notifL)
                render()
            }

            override fun onViewDetachedFromWindow(v: View) {
                Hub.offNotifs(notifL)
            }
        })
        return card
    }

}
