package com.hogwarts.launcher

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.graphics.drawable.toBitmap

class HogwartsNotificationListener : NotificationListenerService() {
    private val h = Handler(Looper.getMainLooper())
    private val seen = HashMap<String, Long>()
    private val names = HashMap<String, String>()
    private val icons = HashMap<String, Bitmap>()
    private var sessionListener: MediaSessionManager.OnActiveSessionsChangedListener? = null

    private val mediaCb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            Hub.fireMedia()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            Hub.fireMedia()
        }

        override fun onSessionDestroyed() {
            Hub.fireMedia()
        }
    }

    override fun onListenerConnected() {
        Hub.listener = this
        refresh(null)
        try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val cn = ComponentName(this, HogwartsNotificationListener::class.java)
            val l = MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }
            sessionListener = l
            msm.addOnActiveSessionsChangedListener(l, cn)
            pick(msm.getActiveSessions(cn))
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        if (Hub.listener === this) Hub.listener = null
        try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val l = sessionListener
            if (l != null) msm.removeOnActiveSessionsChangedListener(l)
        } catch (e: Exception) {
        }
    }

    private fun pick(list: List<MediaController>?) {
        val old = Hub.media
        val next = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        if (old?.sessionToken != next?.sessionToken) {
            try { old?.unregisterCallback(mediaCb) } catch (e: Exception) { }
            Hub.media = next
            try { next?.registerCallback(mediaCb) } catch (e: Exception) { }
        }
        Hub.fireMedia()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        h.post { refresh(sbn) }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        h.post { refresh(null) }
    }

    private fun appName(pkg: String): String = names.getOrPut(pkg) {
        try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    private fun iconFor(pkg: String): Bitmap? {
        val cached = icons[pkg]
        if (cached != null) return cached
        return try {
            val b = packageManager.getApplicationIcon(pkg).toBitmap(96, 96)
            icons[pkg] = b
            b
        } catch (e: Exception) {
            null
        }
    }

    private fun toItem(sbn: StatusBarNotification): NotifItem? {
        val n = sbn.notification ?: return null
        if (sbn.packageName == packageName) return null
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return null
        if (sbn.isOngoing) return null
        if (n.category == Notification.CATEGORY_TRANSPORT) return null
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        if (title.isEmpty() && text.isEmpty()) return null
        return NotifItem(sbn.key, sbn.packageName, appName(sbn.packageName), title, text, sbn.postTime, iconFor(sbn.packageName), n.contentIntent)
    }

    private fun refresh(posted: StatusBarNotification?) {
        val arr = try { activeNotifications } catch (e: Exception) { null }
        val out = ArrayList<NotifItem>()
        if (arr != null) {
            for (s in arr) {
                val ni = toItem(s)
                if (ni != null) out.add(ni)
            }
        }
        out.sortByDescending { it.time }
        Hub.notifs.clear()
        Hub.notifs.addAll(out)
        Hub.fireNotifs()
        if (posted != null) {
            val item = toItem(posted)
            if (item != null && seen[item.key] != item.time) {
                seen[item.key] = item.time
                Hub.firePosted(item)
            }
        }
    }
}
