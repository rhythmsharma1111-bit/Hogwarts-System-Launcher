package com.hogwarts.launcher

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.WindowCompat
import kotlin.math.sin
import kotlin.random.Random

/** A cartoon talking hat drawn in code. */
class HatView(ctx: Context) : View(ctx) {
    var talking = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = SystemClock.uptimeMillis() / 1000f
        c.save()
        c.translate(0f, sin(t * 2f) * h * 0.012f)
        val cx = w / 2f
        val by = h * 0.78f

        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#4A3222")
        rect.set(cx - w * 0.44f, by - h * 0.06f, cx + w * 0.44f, by + h * 0.07f)
        c.drawOval(rect, p)

        path.reset()
        path.moveTo(cx - w * 0.30f, by - h * 0.01f)
        path.quadTo(cx - w * 0.22f, h * 0.50f, cx - w * 0.04f, h * 0.20f)
        path.quadTo(cx + w * 0.06f, h * 0.16f, cx + w * 0.20f, h * 0.10f)
        path.quadTo(cx + w * 0.12f, h * 0.42f, cx + w * 0.30f, by - h * 0.01f)
        path.close()
        p.color = Color.parseColor("#6B4A33")
        c.drawPath(path, p)

        p.style = Paint.Style.STROKE
        p.strokeWidth = w * 0.012f
        p.color = Color.parseColor("#4A3222")
        path.reset()
        path.moveTo(cx - w * 0.22f, h * 0.46f)
        path.quadTo(cx, h * 0.51f, cx + w * 0.20f, h * 0.44f)
        c.drawPath(path, p)
        path.reset()
        path.moveTo(cx - w * 0.27f, h * 0.64f)
        path.quadTo(cx, h * 0.70f, cx + w * 0.26f, h * 0.63f)
        c.drawPath(path, p)

        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#22140C")
        rect.set(cx - w * 0.115f, h * 0.535f, cx - w * 0.055f, h * 0.575f)
        c.drawOval(rect, p)
        rect.set(cx + w * 0.055f, h * 0.535f, cx + w * 0.115f, h * 0.575f)
        c.drawOval(rect, p)

        val open = if (talking) 0.5f + 0.5f * sin(t * 16f) else 0.05f
        rect.set(cx - w * 0.07f, h * 0.60f, cx + w * 0.07f, h * 0.60f + h * (0.012f + open * 0.05f))
        c.drawOval(rect, p)
        c.restore()
        postInvalidateOnAnimation()
    }
}

class SortingHatActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var speech: TextView
    private lateinit var hat: HatView
    private lateinit var enter: TextView
    private var done = false

    private val lines = listOf(
        "Hmm... difficult. Very difficult.",
        "Plenty of courage, I see.",
        "Not a bad mind either...",
        "There's talent, oh yes, and a thirst to prove yourself.",
        "Now... where shall I put you?"
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        val root = FrameLayout(this)
        val scene = SceneView(this)
        scene.lockMode = true
        scene.running = true
        root.addView(scene, FrameLayout.LayoutParams(MP, MP))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(24), dp(80), dp(24), dp(40))
        root.addView(col, FrameLayout.LayoutParams(MP, MP))

        hat = HatView(this)
        col.addView(hat, LinearLayout.LayoutParams(dp(280), dp(280)))

        speech = Ui.text(this, "", 21f, Color.WHITE, Ui.serifItalic)
        speech.gravity = Gravity.CENTER
        speech.minLines = 3
        col.addView(speech, LinearLayout.LayoutParams(MP, WC))

        enter = Ui.text(this, "Enter the Great Hall", 17f, Color.WHITE, Ui.serifBold)
        enter.gravity = Gravity.CENTER
        enter.background = Ui.glass(this, 28f, 190, 200)
        enter.setPadding(dp(30), dp(14), dp(30), dp(14))
        enter.visibility = View.INVISIBLE
        enter.setOnClickListener { finish() }
        val elp = LinearLayout.LayoutParams(WC, WC)
        elp.topMargin = dp(24)
        col.addView(enter, elp)

        val skip = Ui.text(this, "tap anywhere to skip", 11f, Color.parseColor("#8E93AD"), Ui.serifItalic)
        skip.gravity = Gravity.CENTER
        val slp = LinearLayout.LayoutParams(MP, WC)
        slp.topMargin = dp(18)
        col.addView(skip, slp)

        root.setOnClickListener {
            if (!done) {
                handler.removeCallbacksAndMessages(null)
                reveal()
            }
        }
        setContentView(root)
        Tilt.start(this)
        handler.postDelayed({ typeLine(0) }, 700)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Tilt.stop()
        super.onDestroy()
    }

    private fun typeLine(i: Int) {
        if (done) return
        if (i >= lines.size) {
            reveal()
            return
        }
        val s = lines[i]
        hat.talking = true
        speech.text = ""
        var k = 0
        val r = object : Runnable {
            override fun run() {
                if (done) return
                k++
                speech.text = s.substring(0, k)
                if (k < s.length) {
                    handler.postDelayed(this, 45)
                } else {
                    hat.talking = false
                    handler.postDelayed({ typeLine(i + 1) }, 900)
                }
            }
        }
        handler.post(r)
    }

    private fun reveal() {
        if (done) return
        done = true
        val idx = Random.nextInt(4)
        Prefs.house = idx
        hat.talking = true
        speech.setTextColor(House.glowOf(idx))
        speech.typeface = Typeface.create("serif", Typeface.BOLD)
        speech.textSize = 26f
        speech.text = "...better be " + House.names[idx].uppercase() + "!"
        handler.postDelayed({ hat.talking = false }, 1800)
        enter.visibility = View.VISIBLE
        enter.alpha = 0f
        enter.animate().alpha(1f).setDuration(600).start()
    }
}
