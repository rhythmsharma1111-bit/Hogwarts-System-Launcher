package com.hogwarts.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.core.graphics.drawable.toBitmap
import java.util.concurrent.Executors

class AppItem(val label: String, val pkg: String, val cls: String, val icon: Bitmap) {
    val key: String get() = "$pkg/$cls"

    fun intent(): Intent = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(ComponentName(pkg, cls))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
}

object AppRepo {
    @Volatile
    var apps: List<AppItem> = emptyList()

    @Volatile
    var byKey: Map<String, AppItem> = emptyMap()

    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<() -> Unit>()

    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    fun load(ctx: Context) {
        val app = ctx.applicationContext
        exec.execute {
            val pm = app.packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
            val px = app.dp(72)
            val out = ArrayList<AppItem>()
            for (ri in list) {
                try {
                    val ai = ri.activityInfo
                    val label = ri.loadLabel(pm).toString()
                    val bmp = ri.loadIcon(pm).toBitmap(px, px)
                    out.add(AppItem(label, ai.packageName, ai.name, bmp))
                } catch (e: Throwable) {
                }
            }
            out.sortBy { it.label.lowercase() }
            val map = HashMap<String, AppItem>()
            for (a in out) map[a.key] = a
            main.post {
                apps = out
                byKey = map
                for (l in ArrayList(listeners)) l()
            }
        }
    }

    /** Phone, messages, camera and browser, if the phone has defaults for them. */
    fun defaultDock(ctx: Context): List<String> {
        val pm = ctx.packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
        )
        val res = ArrayList<String>()
        for (i in intents) {
            val ri = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY) ?: continue
            val pkg = ri.activityInfo?.packageName ?: continue
            val a = apps.firstOrNull { it.pkg == pkg } ?: continue
            if (!res.contains(a.key)) res.add(a.key)
        }
        return res
    }
}
