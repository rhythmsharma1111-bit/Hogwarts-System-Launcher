package com.hogwarts.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

/** A 3D-looking glass icon plate: tilt-driven shadow, parallax icon and a moving specular band. */
class GlassIconView(ctx: Context) : View(ctx) {
    var bmp: Bitmap? = null
        set(v) {
            field = v
            invalidate()
        }

    private val glow = House.glow()
    private val deep = House.deep()
    private val base = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spec = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val dst = RectF()
    private val clip = Path()
    private var specW = 1f
    private var sheenShader: Shader? = null
    private var specShader: Shader? = null

    init {
        edge.style = Paint.Style.STROKE
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        Tilt.register(this)
    }

    override fun onDetachedFromWindow() {
        Tilt.unregister(this)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sheenShader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.argb(80, 255, 255, 255), Color.argb(10, 255, 255, 255), Shader.TileMode.CLAMP
        )
        specW = w * 0.36f
        specShader = LinearGradient(
            0f, 0f, specW, 0f,
            intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP
        )
        edge.strokeWidth = context.dpf(1.2f)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val sz = w * 0.80f
        val left = w * 0.10f
        val top = w * 0.06f
        val r = sz * 0.28f
        val tx = Tilt.x
        val ty = Tilt.y
        rect.set(left, top, left + sz, top + sz)

        base.shader = null
        base.color = Color.argb(255, 16, 20, 44)
        base.setShadowLayer(sz * 0.08f, -tx * sz * 0.07f, sz * 0.05f + ty * sz * 0.02f, Color.argb(150, 0, 0, 0))
        c.drawRoundRect(rect, r, r, base)
        base.clearShadowLayer()

        base.color = Ui.alpha(deep, 95)
        c.drawRoundRect(rect, r, r, base)
        sheen.shader = sheenShader
        c.drawRoundRect(rect, r, r, sheen)

        val b = bmp
        if (b != null) {
            val isz = sz * 0.70f
            val ox = left + (sz - isz) / 2f + tx * sz * 0.05f
            val oy = top + (sz - isz) / 2f + ty * sz * 0.05f
            dst.set(ox, oy, ox + isz, oy + isz)
            c.drawBitmap(b, null, dst, ip)
        }

        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        val dx = (tx * 0.5f + 0.5f) * (sz + specW) - specW
        c.translate(left + dx, top)
        c.skew(-0.3f, 0f)
        spec.shader = specShader
        c.drawRect(0f, 0f, specW, sz, spec)
        c.restore()

        edge.color = Ui.alpha(glow, 110)
        c.drawRoundRect(rect, r, r, edge)
    }
}

class AppCell(ctx: Context, iconDp: Int, showLabel: Boolean) : LinearLayout(ctx) {
    lateinit var item: AppItem
    private val icon = GlassIconView(ctx)
    private var label: TextView? = null

    init {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        val s = ctx.dp(iconDp)
        addView(icon, LinearLayout.LayoutParams(s, s))
        if (showLabel) {
            val t = Ui.text(ctx, "", 11f)
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.gravity = Gravity.CENTER
            t.setShadowLayer(5f, 0f, 1f, Color.BLACK)
            addView(t, LinearLayout.LayoutParams(ctx.dp(iconDp + 14), WC))
            label = t
        }
        isClickable = true
        isFocusable = true
    }

    fun bind(i: AppItem) {
        item = i
        icon.bmp = i.icon
        label?.text = i.label
    }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        val s = if (pressed) 0.9f else 1f
        animate().scaleX(s).scaleY(s).setDuration(90).start()
    }
}

object ActionMenu {
    fun show(anchor: View, entries: List<Pair<String, () -> Unit>>) {
        val ctx = anchor.context
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.background = Ui.glass(ctx, 18f, 240, 120)
        box.setPadding(ctx.dp(6), ctx.dp(6), ctx.dp(6), ctx.dp(6))
        val pw = PopupWindow(box, ctx.dp(220), WC, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.elevation = ctx.dpf(12f)
        for (e in entries) {
            val t = Ui.text(ctx, e.first, 15f, Color.WHITE, Ui.serif)
            t.setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(12))
            t.setOnClickListener {
                pw.dismiss()
                e.second()
            }
            box.addView(t, LinearLayout.LayoutParams(MP, WC))
        }
        pw.showAsDropDown(anchor, 0, -anchor.height / 2)
    }
}

class DotsView(ctx: Context) : View(ctx) {
    var count = 1
        set(v) {
            field = v
            invalidate()
        }
    var pos = 0f
        set(v) {
            field = v
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = House.glow()

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val gap = 14f * d
        val total = (count - 1) * gap
        val cx = width / 2f - total / 2f
        for (i in 0 until count) {
            val near = (1f - abs(pos - i)).coerceIn(0f, 1f)
            p.color = Ui.mix(Color.argb(110, 255, 255, 255), glow, near)
            c.drawCircle(cx + i * gap, height / 2f, (3f + 2f * near) * d, p)
        }
    }
}

/** Little golden sparks that follow a finger, used on the lock screen. */
class SparkView(ctx: Context) : View(ctx) {
    private class P(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float)

    private val ps = ArrayList<P>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(3)
    private var last = 0L
    private val glow = House.glow()

    fun emit(x: Float, y: Float) {
        for (i in 0 until 3) {
            ps.add(P(x, y, (rnd.nextFloat() - 0.5f) * 160f, (rnd.nextFloat() - 0.3f) * 160f, 1f))
        }
        while (ps.size > 160) ps.removeAt(0)
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceAtMost(0.05f)
        last = now
        val iter = ps.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            p.life -= dt * 1.4f
            if (p.life <= 0f) {
                iter.remove()
                continue
            }
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vy += 120f * dt
            paint.color = Ui.alpha(glow, (255 * p.life).toInt().coerceIn(0, 255))
            c.drawCircle(p.x, p.y, 2f + 4f * p.life, paint)
        }
        if (ps.isNotEmpty()) postInvalidateOnAnimation() else last = 0L
    }
}

/** Equaliser bars shown in the island while music plays. */
class EqView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        p.strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(c: Canvas) {
        p.color = House.glow()
        val t = SystemClock.uptimeMillis() / 140.0
        val w = width.toFloat()
        val h = height.toFloat()
        val bw = w / 7f
        p.strokeWidth = bw
        for (i in 0 until 4) {
            val f = 0.3f + 0.7f * abs(sin(t + i * 1.7)).toFloat()
            val x = bw * (0.9f + i * 1.7f)
            c.drawLine(x, h / 2f - f * h / 2f, x, h / 2f + f * h / 2f, p)
        }
        postInvalidateOnAnimation()
    }
}
