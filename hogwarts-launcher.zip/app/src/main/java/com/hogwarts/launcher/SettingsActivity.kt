package com.hogwarts.launcher

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/** Setup checklist + options. Opened from the app list, or by holding the clock on the home screen. */
class SettingsActivity : Activity() {
    private val statuses = ArrayList<Pair<TextView, () -> Boolean>>()
    private lateinit var col: LinearLayout
    private val glow = House.glow()
    private val muted = Color.parseColor("#B8BCCF")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#070A1E"))
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        scroll.addView(col, FrameLayout.LayoutParams(MP, WC))
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { _, ins ->
            val bars = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            col.setPadding(dp(16), bars.top + dp(16), dp(16), bars.bottom + dp(28))
            ins
        }
        setContentView(scroll)
        build()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        for (p in statuses) {
            val ok = try { p.second() } catch (e: Exception) { false }
            p.first.text = if (ok) "\u2713 done" else "to do"
            p.first.setTextColor(if (ok) Color.parseColor("#6BE39A") else glow)
        }
    }

    private fun lp(top: Int): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(MP, WC)
        l.topMargin = dp(top)
        return l
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = Ui.glass(this, 20f, 150, 80)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        return c
    }

    private fun button(label: String, act: () -> Unit): TextView {
        val btn = Ui.text(this, label, 13.5f, Color.WHITE, Ui.serifBold)
        btn.background = Ui.glass(this, 18f, 170, 140)
        btn.setPadding(dp(18), dp(8), dp(18), dp(8))
        btn.setOnClickListener {
            try {
                act()
            } catch (e: Exception) {
                Toast.makeText(this, "Couldn't open that screen", Toast.LENGTH_SHORT).show()
            }
        }
        return btn
    }

    private fun heading(s: String) {
        col.addView(Ui.text(this, s, 13f, glow, Ui.serifBold), lp(22))
    }

    private fun step(title: String, desc: String, ok: (() -> Boolean)?, label: String, action: () -> Unit) {
        val c = card()
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(Ui.text(this, title, 16f, Color.WHITE, Ui.serifBold), LinearLayout.LayoutParams(0, WC, 1f))
        if (ok != null) {
            val st = Ui.text(this, "", 12f, glow)
            top.addView(st)
            statuses.add(Pair(st, ok))
        }
        c.addView(top)
        c.addView(Ui.text(this, desc, 12.5f, muted), lp(4))
        val bl = LinearLayout.LayoutParams(WC, WC)
        bl.topMargin = dp(10)
        c.addView(button(label, action), bl)
        col.addView(c, lp(10))
    }

    private fun toggle(title: String, desc: String, cur: Boolean, set: (Boolean) -> Unit) {
        val c = card()
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.addView(Ui.text(this, title, 15f, Color.WHITE, Ui.serifBold))
        t.addView(Ui.text(this, desc, 12f, muted))
        c.addView(t, LinearLayout.LayoutParams(0, WC, 1f))
        val sw = Switch(this)
        sw.isChecked = cur
        sw.setOnCheckedChangeListener { _, v ->
            set(v)
            HogwartsAccessibilityService.instance?.applyPrefs()
        }
        c.addView(sw)
        col.addView(c, lp(10))
    }

    private fun slider(title: String, max: Int, cur: Int, set: (Int) -> Unit) {
        val c = card()
        val label = Ui.text(this, title + ": " + cur, 15f, Color.WHITE, Ui.serifBold)
        c.addView(label)
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = cur
        sb.progressTintList = android.content.res.ColorStateList.valueOf(glow)
        sb.thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                set(p)
                label.text = title + ": " + p
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                HogwartsAccessibilityService.instance?.applyPrefs()
            }
        })
        c.addView(sb, lp(6))
        col.addView(c, lp(10))
    }

    private fun isDefaultHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    private fun pkgUri(): Uri = Uri.parse("package:" + packageName)

    private fun build() {
        col.addView(Ui.text(this, "Hogwarts System Launcher", 28f, Color.WHITE, Ui.serifBold))
        col.addView(
            Ui.text(this, "Seven small spells to switch on all the magic. Do them in order; each button opens the right Android screen.", 13.5f, muted, Ui.serifItalic),
            lp(6)
        )

        heading("SETUP")
        step("1 \u00B7 Make it your home screen", "Choose Hogwarts System Launcher as your default home app.", { isDefaultHome() }, "Choose home app") {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        }
        step(
            "2 \u00B7 Allow restricted settings",
            "Apps installed from a file are blocked from Accessibility until you allow it. Open App info, tap the three dots at the top right, then \u201CAllow restricted settings\u201D. (If you don't see the three dots, skip this.)",
            null, "Open App info"
        ) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri()))
        }
        step(
            "3 \u00B7 Hogwarts Magic (Accessibility)",
            "Turns on the dynamic island, the pull-down notification and control centres over every app, and the lock screen. It never reads your screen.",
            { HogwartsAccessibilityService.instance != null }, "Open Accessibility"
        ) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        step(
            "4 \u00B7 Owl Post (Notification access)",
            "Lets the island, the notification centre and the lock screen show your notifications and the music that is playing.",
            { NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName) }, "Open Notification access"
        ) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        step(
            "5 \u00B7 Display over other apps",
            "Helps the lock screen appear reliably when the screen turns off.",
            { Settings.canDrawOverlays(this) }, "Open permission"
        ) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri()))
        }
        step(
            "6 \u00B7 Brightness and rotation tiles",
            "Lets the control centre change brightness and auto-rotate.",
            { Settings.System.canWrite(this) }, "Open permission"
        ) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkgUri()))
        }
        step(
            "7 \u00B7 Nox (Do Not Disturb tile)",
            "Optional. Lets the Nox tile switch Do Not Disturb on and off.",
            { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted }, "Open permission"
        ) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        step(
            "Keep the magic alive",
            "On OnePlus: Settings, Apps, App management, Hogwarts System Launcher, Battery usage, Allow background activity. Also lock the app in the Recents screen so it isn't cleaned up.",
            { (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName) }, "Ignore battery limits"
        ) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri()))
        }

        heading("OPTIONS")
        toggle("Hogwarts lock screen", "Shows the castle lock screen when the screen turns off. Your PIN or fingerprint still protects the phone.", Prefs.lockEnabled) {
            Prefs.lockEnabled = it
        }
        toggle("Always show the island", "Keep the small pill visible at the top. Turn off to show it only for events.", Prefs.islandIdle) {
            Prefs.islandIdle = it
        }
        toggle("Pull-down gestures", "Swipe down at the top-left for notifications, top-right for the control centre. This replaces Android's own pull-down in those two corners.", Prefs.strips) {
            Prefs.strips = it
        }
        slider("Island height (dp from top)", 40, Prefs.islandY) { Prefs.islandY = it }
        slider("3D tilt strength", 100, Prefs.tilt) { Prefs.tilt = it }

        heading("HOUSE")
        val hc = card()
        hc.addView(Ui.text(this, "You are in " + House.name() + " (" + House.mottos[House.idx()] + ")", 14f, Color.WHITE, Ui.serifItalic))
        val hb = LinearLayout.LayoutParams(WC, WC)
        hb.topMargin = dp(10)
        hc.addView(button("Visit the Sorting Hat again") {
            startActivity(Intent(this, SortingHatActivity::class.java))
        }, hb)
        col.addView(hc, lp(10))

        col.addView(
            Ui.text(this, "Tip: on the home screen, hold the clock to come back here. Double-tap the clock to lock the phone.", 12f, Color.parseColor("#8E93AD"), Ui.serifItalic),
            lp(22)
        )
    }
}
