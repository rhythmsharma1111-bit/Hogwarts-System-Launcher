package com.hogwarts.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.graphics.drawable.toBitmap
import kotlin.math.max
import kotlin.math.min

/**
 * The dynamic island: a black pill at the top of the screen, drawn over every app by the
 * accessibility service. Idle -> compact (notification, charging, track) -> expanded (music).
 */
class Island(private val ctx: Context, private val wm: WindowManager) {
    private val root = FrameLayout(ctx)
    private val pill = FrameLayout(ctx)
    private val bg = GradientDrawable()
    private val icon = ImageView(ctx)
    private val textBox = LinearLayout(ctx)
    private val title = Ui.text(ctx, "", 13f, Color.WHITE, Typeface.DEFAULT_BOLD)
    private val sub = Ui.text(ctx, "", 11.5f, Color.parseColor("#B8BCCF"))
    private val eq = EqView(ctx)
    private val controls = LinearLayout(ctx)
    private val btnPlay = ImageView(ctx)
    private val h = Handler(Looper.getMainLooper())
    private val sw = ctx.resources.displayMetrics.widthPixels
    private val margin = ctx.dp(16)
    private val iconCache = HashMap<String, Bitmap>()

    private var attached = false
    private var state = 0 // 0 idle, 1 compact, 2 expanded
    private var tap: (() -> Unit)? = null
    private var anim: ValueAnimator? = null
    private var curW = 0
    private var curH = 0
    private var lastSig = ""
    private var eqShown = false
    private val toIdleRun = Runnable { goIdle() }

    private fun idleW() = ctx.dp(if (Hub.isPlaying()) 112 else 92)
    private fun idleH() = ctx.dp(28)
    private fun compactW() = min(sw - ctx.dp(40), ctx.dp(280))
    private fun compactH() = ctx.dp(46)
    private fun expandW() = min(sw - ctx.dp(24), ctx.dp(380))
    private fun expandH() = ctx.dp(128)

    init {
        bg.setColor(Color.BLACK)
        bg.setStroke(ctx.dp(1), Ui.alpha(House.glow(), 70))
        bg.cornerRadius = ctx.dpf(14f)
        pill.background = bg
        pill.clipToOutline = true
        root.setPadding(margin, 0, margin, margin)
        root.addView(pill, FrameLayout.LayoutParams(ctx.dp(92), ctx.dp(28), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        pill.addView(icon, FrameLayout.LayoutParams(ctx.dp(24), ctx.dp(24), Gravity.START or Gravity.CENTER_VERTICAL))

        textBox.orientation = LinearLayout.VERTICAL
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        sub.maxLines = 1
        sub.ellipsize = TextUtils.TruncateAt.END
        textBox.addView(title, LinearLayout.LayoutParams(MP, WC))
        textBox.addView(sub, LinearLayout.LayoutParams(MP, WC))
        val tlp = FrameLayout.LayoutParams(MP, WC, Gravity.CENTER_VERTICAL)
        tlp.rightMargin = ctx.dp(16)
        pill.addView(textBox, tlp)

        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        addButton(ImageView(ctx), android.R.drawable.ic_media_previous) { Hub.media?.transportControls?.skipToPrevious() }
        addButton(btnPlay, android.R.drawable.ic_media_pause) {
            val mc = Hub.media
            if (mc != null) {
                if (Hub.isPlaying()) mc.transportControls.pause() else mc.transportControls.play()
            }
        }
        addButton(ImageView(ctx), android.R.drawable.ic_media_next) { Hub.media?.transportControls?.skipToNext() }
        val clp = FrameLayout.LayoutParams(WC, WC, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        clp.bottomMargin = ctx.dp(8)
        pill.addView(controls, clp)

        val elp = FrameLayout.LayoutParams(ctx.dp(18), ctx.dp(14), Gravity.END or Gravity.CENTER_VERTICAL)
        elp.rightMargin = ctx.dp(14)
        pill.addView(eq, elp)

        icon.visibility = View.GONE
        textBox.visibility = View.GONE
        controls.visibility = View.GONE
        eq.visibility = View.GONE

        var downY = 0f
        pill.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> downY = e.rawY
                MotionEvent.ACTION_UP -> {
                    if (downY - e.rawY > ctx.dp(16)) goIdle() else onTap()
                }
            }
            true
        }
    }

    private fun addButton(iv: ImageView, res: Int, act: () -> Unit) {
        iv.setImageResource(res)
        iv.setColorFilter(Color.WHITE)
        iv.setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(10), ctx.dp(6))
        iv.setOnClickListener {
            act()
            h.removeCallbacks(toIdleRun)
            h.postDelayed(toIdleRun, 7000)
        }
        controls.addView(iv, LinearLayout.LayoutParams(ctx.dp(64), ctx.dp(40)))
    }

    private fun appIcon(pkg: String): Bitmap? {
        val c = iconCache[pkg]
        if (c != null) return c
        return try {
            val b = ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96)
            iconCache[pkg] = b
            b
        } catch (e: Exception) {
            null
        }
    }

    // ---- public API -------------------------------------------------------

    fun start() {
        curW = idleW()
        curH = idleH()
        val lp = pill.layoutParams
        lp.width = curW
        lp.height = curH
        pill.layoutParams = lp
        bg.cornerRadius = curH / 2f
        goIdle()
    }

    fun destroy() {
        h.removeCallbacksAndMessages(null)
        anim?.cancel()
        detach()
    }

    fun showNotification(n: NotifItem) {
        if (state == 2) return
        val t = if (n.title.isNotEmpty()) n.title else n.app
        showCompact(n.icon, 0, t, n.text, 4500L) {
            try {
                n.pi?.send()
            } catch (e: Exception) {
            }
        }
    }

    fun showCharging() {
        if (state == 2) return
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else 0
        showCompact(null, android.R.drawable.ic_lock_idle_charging, "Charging", "$pct%", 3500L, null)
    }

    fun onMediaChanged() {
        updatePlayIcon()
        val playing = Hub.isPlaying()
        if (state == 2) {
            if (Hub.media == null) goIdle() else bindMedia()
            return
        }
        val sig = Hub.mediaTitle() + "|" + playing
        val changed = sig != lastSig
        lastSig = sig
        if (state == 0) {
            if (changed && playing && Hub.media != null) {
                val pkg = Hub.media?.packageName
                showCompact(if (pkg != null) appIcon(pkg) else null, 0, Hub.mediaTitle(), Hub.mediaArtist(), 3000L, null)
            } else if (playing != eqShown) {
                goIdle()
            }
        }
    }

    // ---- states -----------------------------------------------------------

    private fun layoutIcon(centered: Boolean) {
        val lp = icon.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = ctx.dp(14)
        lp.gravity = if (centered) Gravity.START or Gravity.CENTER_VERTICAL else Gravity.START or Gravity.TOP
        lp.topMargin = if (centered) 0 else ctx.dp(14)
        icon.layoutParams = lp
    }

    private fun layoutText(left: Int, centered: Boolean) {
        val lp = textBox.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = left
        lp.gravity = if (centered) Gravity.CENTER_VERTICAL else Gravity.TOP
        lp.topMargin = if (centered) 0 else ctx.dp(12)
        textBox.layoutParams = lp
    }

    private fun goIdle() {
        h.removeCallbacks(toIdleRun)
        state = 0
        tap = null
        icon.visibility = View.GONE
        textBox.visibility = View.GONE
        controls.visibility = View.GONE
        val playing = Hub.isPlaying()
        eqShown = playing
        eq.visibility = if (playing) View.VISIBLE else View.GONE
        if (Prefs.islandIdle || playing) {
            morph(idleW(), idleH(), null)
        } else if (attached) {
            morph(idleW(), idleH()) { detach() }
        }
    }

    private fun showCompact(bm: Bitmap?, res: Int, t: String, s: String, durMs: Long, onTap: (() -> Unit)?) {
        h.removeCallbacks(toIdleRun)
        state = 1
        tap = onTap
        val hasIcon = bm != null || res != 0
        if (bm != null) icon.setImageBitmap(bm) else if (res != 0) icon.setImageResource(res)
        icon.visibility = if (hasIcon) View.VISIBLE else View.GONE
        layoutIcon(true)
        layoutText(ctx.dp(if (hasIcon) 50 else 18), true)
        title.text = t
        sub.text = s
        sub.visibility = if (s.isEmpty()) View.GONE else View.VISIBLE
        textBox.visibility = View.VISIBLE
        controls.visibility = View.GONE
        eq.visibility = View.GONE
        morph(compactW(), compactH(), null)
        if (durMs > 0) h.postDelayed(toIdleRun, durMs)
    }

    private fun showMedia() {
        if (Hub.media == null) return
        h.removeCallbacks(toIdleRun)
        state = 2
        tap = null
        bindMedia()
        icon.visibility = View.VISIBLE
        textBox.visibility = View.VISIBLE
        controls.visibility = View.VISIBLE
        eq.visibility = View.GONE
        layoutIcon(false)
        layoutText(ctx.dp(54), false)
        morph(expandW(), expandH(), null)
        h.postDelayed(toIdleRun, 7000)
    }

    private fun bindMedia() {
        title.text = Hub.mediaTitle()
        sub.text = Hub.mediaArtist()
        sub.visibility = if (sub.text.isEmpty()) View.GONE else View.VISIBLE
        val pkg = Hub.media?.packageName
        if (pkg != null) {
            val b = appIcon(pkg)
            if (b != null) icon.setImageBitmap(b)
        }
        updatePlayIcon()
    }

    private fun updatePlayIcon() {
        btnPlay.setImageResource(if (Hub.isPlaying()) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
    }

    private fun onTap() {
        when (state) {
            0 -> if (Hub.media != null) showMedia() else showCompact(null, 0, Fmt.time(ctx), Fmt.date(), 3500L, null)
            1 -> {
                val t = tap
                goIdle()
                t?.invoke()
            }
            else -> goIdle()
        }
    }

    // ---- window + animation -----------------------------------------------

    private fun attach() {
        if (attached) return
        val lp = WindowManager.LayoutParams(
            curW + margin * 2, curH + margin,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = ctx.dp(Prefs.islandY)
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try {
            wm.addView(root, lp)
            attached = true
        } catch (e: Exception) {
        }
    }

    private fun detach() {
        if (!attached) return
        try {
            wm.removeView(root)
        } catch (e: Exception) {
        }
        attached = false
    }

    private fun growWindow(w: Int, hh: Int) {
        if (!attached) return
        val lp = root.layoutParams as WindowManager.LayoutParams
        val nw = w + margin * 2
        val nh = hh + margin
        if (lp.width != nw || lp.height != nh) {
            lp.width = nw
            lp.height = nh
            try {
                wm.updateViewLayout(root, lp)
            } catch (e: Exception) {
            }
        }
    }

    private fun morph(toW: Int, toH: Int, end: (() -> Unit)?) {
        attach()
        anim?.cancel()
        val fromW = curW
        val fromH = curH
        growWindow(max(fromW, toW), max(fromH, toH))
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 380
        a.interpolator = OvershootInterpolator(0.9f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            curW = (fromW + (toW - fromW) * f).toInt()
            curH = (fromH + (toH - fromH) * f).toInt()
            val lp = pill.layoutParams
            lp.width = curW
            lp.height = curH
            pill.layoutParams = lp
            bg.cornerRadius = min(curH / 2f, ctx.dpf(26f))
        }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false

            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (cancelled) return
                curW = toW
                curH = toH
                growWindow(toW, toH)
                end?.invoke()
            }
        })
        anim = a
        a.start()
    }
}
