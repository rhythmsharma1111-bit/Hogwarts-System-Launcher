# Hogwarts System Launcher

A Harry Potter themed Android launcher (Kotlin, no image assets: everything is drawn in code).

* 3D tilt-parallax castle scene, glass icons with moving highlights, 3D page turn and drawer
* Lock screen, dynamic island, Owl Post (notification centre), Enchantments (control centre)
* App drawer with search, pins, dock, Sorting Hat, spell of the day

Build: Android Studio -> open this folder -> Build > Build APK(s)
or: `gradle assembleRelease` (Gradle 8.9, JDK 17, Android SDK 34).
The APK is signed with the bundled `app/hogwarts.keystore` (password `hogwarts123`) so that
later builds update over earlier ones. It is a personal key: do not use it for the Play Store.
